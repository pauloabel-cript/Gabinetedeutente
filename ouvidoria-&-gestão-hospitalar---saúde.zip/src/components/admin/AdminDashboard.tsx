import React from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Heart, 
  Lightbulb, 
  TrendingUp, 
  FileText,
  UserX,
  PhoneCall
} from 'lucide-react';
import { FeedbackItem, FeedbackStatus, FeedbackType } from '../../types/feedback';
import { HOSPITAL_SECTORS } from '../../data/mockData';

interface AdminDashboardProps {
  feedbacks: FeedbackItem[];
  onSelectFeedback: (id: string) => void;
  onFilterChange: (type?: FeedbackType, status?: FeedbackStatus) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  feedbacks,
  onSelectFeedback,
  onFilterChange,
}) => {
  const total = feedbacks.length;
  const reclamacoes = feedbacks.filter(f => f.type === 'reclamacao').length;
  const sugestoes = feedbacks.filter(f => f.type === 'sugestao').length;
  const elogios = feedbacks.filter(f => f.type === 'elogio').length;

  const resolvidos = feedbacks.filter(f => f.type !== undefined && (f.status === 'resolvido' || f.status === 'arquivado')).length;
  const taxaResolucao = total > 0 ? Math.round((resolvidos / total) * 100) : 0;

  const pendentesCriticos = feedbacks.filter(
    f => (f.priority === 'critica' || f.priority === 'alta') && f.status !== 'resolvido' && f.status !== 'arquivado'
  );

  // Sector breakdown
  const sectorCounts = HOSPITAL_SECTORS.map(sec => {
    const items = feedbacks.filter(f => f.sector === sec.id);
    const recs = items.filter(f => f.type === 'reclamacao').length;
    const elos = items.filter(f => f.type === 'elogio').length;
    const sugs = items.filter(f => f.type === 'sugestao').length;
    return {
      sector: sec,
      total: items.length,
      recs,
      elos,
      sugs,
    };
  }).filter(s => s.total > 0).sort((a, b) => b.total - a.total);

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total */}
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 font-medium block">Total Geral</span>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {total}
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">Neste período</span>
        </div>

        {/* Reclamações */}
        <button
          type="button"
          onClick={() => onFilterChange('reclamacao')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-rose-300 text-left transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">Reclamações</span>
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-rose-700 mt-1 tabular-nums">
            {reclamacoes}
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            {total > 0 ? `${Math.round((reclamacoes / total) * 100)}% do volume` : '0%'}
          </span>
        </button>

        {/* Elogios */}
        <button
          type="button"
          onClick={() => onFilterChange('elogio')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-emerald-300 text-left transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">Elogios</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            {elogios}
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            {total > 0 ? `${Math.round((elogios / total) * 100)}% do volume` : '0%'}
          </span>
        </button>

        {/* Sugestões */}
        <button
          type="button"
          onClick={() => onFilterChange('sugestao')}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-indigo-300 text-left transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">Sugestões</span>
            <span className="w-2 h-2 rounded-full bg-indigo-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-700 mt-1 tabular-nums">
            {sugestoes}
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            {total > 0 ? `${Math.round((sugestoes / total) * 100)}% do volume` : '0%'}
          </span>
        </button>

        {/* Taxa de Resolução */}
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 font-medium block">Resolutividade</span>
          <div className="text-2xl font-bold font-mono text-teal-800 mt-1 tabular-nums">
            {taxaResolucao}%
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">{resolvidos} concluídos</span>
        </div>

        {/* Tempo Médio SLA */}
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 font-medium block">Tempo Médio SLA</span>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            2.4 d
          </div>
          <span className="text-[11px] text-emerald-600 mt-0.5 block">Dentro da meta (≤ 5d)</span>
        </div>
      </div>

      {/* Critical Attention Banner (if pending critical cases) */}
      {pendentesCriticos.length > 0 && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span className="text-xs font-bold text-rose-900 uppercase tracking-wide">
                Atenção Imediata: {pendentesCriticos.length} Casos de Prioridade Alta ou Crítica Pendentes
              </span>
            </div>
            <span className="text-xs text-rose-700 font-medium">Requerem resposta em &lt; 24h</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3">
            {pendentesCriticos.slice(0, 4).map(item => (
              <button
                key={item.id}
                onClick={() => onSelectFeedback(item.id)}
                className="bg-white p-3 rounded-lg border border-rose-200/80 hover:border-rose-400 text-left transition-colors flex items-center justify-between group"
              >
                <div className="truncate mr-3">
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-0.5">
                    <span className="font-mono font-bold text-slate-800">{item.protocolNumber}</span>
                    <span aria-hidden="true">·</span>
                    <span className="capitalize">{item.type}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-rose-700 font-bold uppercase">{item.priority}</span>
                  </div>
                  <div className="text-xs font-semibold text-slate-900 truncate">
                    {item.subject}
                  </div>
                </div>
                <span className="text-xs text-rose-700 group-hover:translate-x-0.5 transition-transform font-bold">
                  Tratar &rarr;
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Two Column Layout: Sectors Distribution + Channel & Anonymity Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sectors Breakdown */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Distribuição de Manifestações por Setor Hospitalar
              </h3>
              <p className="text-xs text-slate-500">
                Volume de reclamações, elogios e sugestões por departamento
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {sectorCounts.map(({ sector, total: secTotal, recs, elos, sugs }) => {
              const recPct = secTotal > 0 ? (recs / secTotal) * 100 : 0;
              const eloPct = secTotal > 0 ? (elos / secTotal) * 100 : 0;
              const sugPct = secTotal > 0 ? (sugs / secTotal) * 100 : 0;

              return (
                <div key={sector.id} className="p-2.5 rounded-lg hover:bg-slate-50 transition-colors border border-slate-100">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <div className="font-medium text-slate-900">
                      {sector.label}
                      <span className="text-[11px] text-slate-400 font-normal ml-2">
                        (Resp: {sector.responsibleOfficer})
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs font-mono tabular-nums">
                      <span className="text-rose-700 font-semibold">{recs} rec</span>
                      <span className="text-emerald-700 font-semibold">{elos} elo</span>
                      <span className="text-indigo-700 font-semibold">{sugs} sug</span>
                      <span className="text-slate-800 font-bold ml-1">{secTotal} total</span>
                    </div>
                  </div>

                  {/* Segmented bar */}
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden flex">
                    <div style={{ width: `${recPct}%` }} className="bg-rose-500 h-full" title={`Reclamações: ${recs}`} />
                    <div style={{ width: `${eloPct}%` }} className="bg-emerald-500 h-full" title={`Elogios: ${elos}`} />
                    <div style={{ width: `${sugPct}%` }} className="bg-indigo-500 h-full" title={`Sugestões: ${sugs}`} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quality Insights & Channel Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-5">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              Canais de Entrada
            </h3>
            <p className="text-xs text-slate-500 mb-3">Origem dos registos recebidos</p>

            <div className="space-y-2 text-xs">
              {[
                { label: 'Portal Web do Utente', count: feedbacks.filter(f => f.channel === 'web').length, icon: FileText },
                { label: 'Linha Verde Telefónica', count: feedbacks.filter(f => f.channel === 'telefone').length, icon: PhoneCall },
                { label: 'Atendimento Presencial (Balcão)', count: feedbacks.filter(f => f.channel === 'presencial').length, icon: CheckCircle2 },
              ].map(c => (
                <div key={c.label} className="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-2 text-slate-700">
                    <c.icon className="w-3.5 h-3.5 text-teal-700" />
                    <span>{c.label}</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">{c.count}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              Indicadores de Privacidade
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-100">
                <span className="text-slate-600">Manifestações Anónimas:</span>
                <span className="font-mono font-bold text-slate-800 tabular-nums">
                  {feedbacks.filter(f => f.isAnonymous).length} ({total > 0 ? Math.round((feedbacks.filter(f => f.isAnonymous).length / total) * 100) : 0}%)
                </span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-100">
                <span className="text-slate-600">Com Identificação e Contato:</span>
                <span className="font-mono font-bold text-slate-800 tabular-nums">
                  {feedbacks.filter(f => !f.isAnonymous).length} ({total > 0 ? Math.round((feedbacks.filter(f => !f.isAnonymous).length / total) * 100) : 0}%)
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
