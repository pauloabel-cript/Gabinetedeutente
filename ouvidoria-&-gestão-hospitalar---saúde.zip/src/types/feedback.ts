export type FeedbackType = 'reclamacao' | 'sugestao' | 'elogio';

export type FeedbackStatus = 
  | 'recebido' 
  | 'em_analise' 
  | 'em_atendimento' 
  | 'resolvido' 
  | 'arquivado';

export type FeedbackPriority = 'baixa' | 'media' | 'alta' | 'critica';

export type IntakeChannel = 'web' | 'telefone' | 'presencial';

export type ReporterRole = 
  | 'paciente' 
  | 'familiar' 
  | 'funcionario' 
  | 'visitante' 
  | 'outro';

export type HospitalSector = 
  | 'triagem_urgencia'
  | 'consultas_externas'
  | 'enfermagem'
  | 'corpo_clinico'
  | 'farmacia'
  | 'laboratorio_imagem'
  | 'bloco_operatorio'
  | 'maternidade_pediatria'
  | 'limpeza_higiene'
  | 'alimentacao_nutricao'
  | 'recepcao_atendimento'
  | 'faturacao_caixa'
  | 'seguranca_instalacoes';

export interface TimelineEvent {
  id: string;
  timestamp: string;
  author: string;
  action: string;
  description: string;
  isPublic: boolean;
}

export interface InternalNote {
  id: string;
  authorName: string;
  authorRole: string;
  timestamp: string;
  note: string;
}

export interface Attachment {
  name: string;
  size: string;
  type: string;
  url?: string;
}

export interface FeedbackItem {
  id: string;
  protocolNumber: string; // e.g. "HOSP-2026-89412"
  accessPin: string; // 4-digit PIN for tracking
  type: FeedbackType;
  status: FeedbackStatus;
  priority: FeedbackPriority;
  channel: IntakeChannel;
  createdAt: string;
  updatedAt: string;
  targetDate?: string;
  
  // Manifestante
  isAnonymous: boolean;
  reporterName?: string;
  reporterPhone?: string;
  reporterEmail?: string;
  reporterRole: ReporterRole;
  
  // Localização & Assunto
  facilityUnit: string; // e.g. "Hospital Central de Maputo - Bloco B"
  sector: HospitalSector;
  subject: string;
  description: string;
  attachments?: Attachment[];
  
  // Tratativa e Resposta Oficial
  officialResponse?: {
    respondedAt: string;
    respondedBy: string;
    message: string;
    actionTaken?: string;
  };
  
  // Réplicas do Utente (Mensagens enviadas pelo paciente no acompanhamento)
  followupMessages?: Array<{
    id: string;
    sender: 'utente' | 'ouvidoria';
    timestamp: string;
    message: string;
  }>;
  
  // Notas internas confidenciais da ouvidoria
  internalNotes: InternalNote[];
  
  // Histórico de auditoria
  timeline: TimelineEvent[];
  
  // Notificações enviadas (simulação de SMS / Email)
  notificationsSent: Array<{
    timestamp: string;
    channel: 'sms' | 'email' | 'whatsapp';
    destination: string;
    status: 'enviado' | 'entregue';
    preview: string;
  }>;
}

export interface SectorConfig {
  id: HospitalSector;
  label: string;
  responsibleOfficer: string;
  avgSlaDays: number;
}

export type UserRole = 'admin' | 'gestor';

export interface SystemUser {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  title: string;
  assignedHospital: string;
  phone?: string;
  isActive: boolean;
  createdAt: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorName: string;
  actorRole: string;
  action: string;
  details: string;
}

export interface OfficeContactSettings {
  hotlinePhone: string;
  whatsappPhone: string;
  mobileSmsPhone: string;
  officialEmail: string;
  operatingHours: string;
  locationOffice: string;
  smsProvider: 'manual_sim' | 'android_gateway' | 'bulksms_mz' | 'infobip' | 'twilio' | 'vodacom_api';
  smsApiKey?: string;
  androidGatewayUrl?: string;
  smsSenderId: string;
  slaHours: string;
  slaMaxDays: string;
}

