import React, { useState } from 'react';
import { 
  X, 
  Send, 
  Lock, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  MessageSquare, 
  FileText, 
  Smartphone, 
  Mail, 
  User, 
  History,
  Tag,
  Share2,
  Zap,
  Loader2,
  Radio
} from 'lucide-react';
import { FeedbackItem, FeedbackPriority, FeedbackStatus } from '../../types/feedback';
import { useFeedback } from '../../context/FeedbackContext';
import { HOSPITAL_SECTORS } from '../../data/mockData';

interface FeedbackDetailModalProps {
  item: FeedbackItem | null;
  onClose: () => void;
}

export const FeedbackDetailModal: React.FC<FeedbackDetailModalProps> = ({ item, onClose }) => {
  const { 
    currentUser, 
    updateStatus, 
    updatePriority, 
    addInternalNote, 
    sendOfficialResponse,
    officeSettings
  } = useFeedback();

  const [activeTab, setActiveTab] = useState<'details' | 'response' | 'internal_notes' | 'audit' | 'notifications'>('details');
  
  // Status change state
  const [selectedStatus, setSelectedStatus] = useState<FeedbackStatus>(item?.status || 'recebido');
  const [statusReason, setStatusReason] = useState('');
  
  // Internal note state
  const [newNote, setNewNote] = useState('');
  
  // Official response state
  const [responseMessage, setResponseMessage] = useState(item?.officialResponse?.message || '');
  const [actionTaken, setActionTaken] = useState(item?.officialResponse?.actionTaken || '');
  const [markResolved, setMarkResolved] = useState(true);
  const [sendAutoEmail, setSendAutoEmail] = useState<boolean>(Boolean(item?.reporterEmail));
  const [sendAutoSms, setSendAutoSms] = useState<boolean>(Boolean(item?.reporterPhone));
  const [isSubmittingResponse, setIsSubmittingResponse] = useState(false);
  const [responseSentFeedback, setResponseSentFeedback] = useState(false);
  const [autoDeliveryReceipt, setAutoDeliveryReceipt] = useState<{
    email: boolean;
    sms: boolean;
    emailAddress?: string;
    phoneNumber?: string;
    timestamp: string;
  } | null>(null);

  if (!item) return null;

  const sectorInfo = HOSPITAL_SECTORS.find(s => s.id === item.sector);

  const handleUpdateStatus = () => {
    updateStatus(item.id, selectedStatus, statusReason || undefined);
    setStatusReason('');
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    addInternalNote(item.id, newNote.trim());
    setNewNote('');
  };

  const handleSendResponse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!responseMessage.trim()) return;

    setIsSubmittingResponse(true);

    setTimeout(() => {
      sendOfficialResponse(
        item.id, 
        responseMessage.trim(), 
        actionTaken.trim() || undefined, 
        markResolved,
        { sendEmail: sendAutoEmail, sendSms: sendAutoSms }
      );
      setIsSubmittingResponse(false);
      setResponseSentFeedback(true);
      setAutoDeliveryReceipt({
        email: sendAutoEmail && Boolean(item.reporterEmail),
        sms: sendAutoSms && Boolean(item.reporterPhone),
        emailAddress: item.reporterEmail,
        phoneNumber: item.reporterPhone,
        timestamp: new Date().toLocaleTimeString('pt-PT'),
      });
      setTimeout(() => setResponseSentFeedback(false), 9000);
    }, 650);
  };

  // Quick Response Templates
  const applyTemplate = (type: 'acolhimento' | 'apuracao' | 'elogio_agradecimento' | 'conclusao') => {
    const greeting = item.isAnonymous ? 'Estimado(a) Cidadão(ã),' : `Estimado(a) Sr.(a) ${item.reporterName || 'Utente'},`;
    
    if (type === 'acolhimento') {
      setResponseMessage(
        `${greeting}\n\nAcusamos a receção da sua manifestação referente ao setor de ${sectorInfo?.label || 'atendimento'}. Informamos que o processo foi acolhido pelo Gabinete de Utente e os factos estão a ser reunidos para avaliação inicial com a equipa técnica.`
      );
      setActionTaken('Abertura formal de processo no Gabinete do Utente e notificação da chefia de setor.');
    } else if (type === 'apuracao') {
      setResponseMessage(
        `${greeting}\n\nEm seguimento à sua manifestação (${item.protocolNumber}), informamos que o caso foi encaminhado para a Direção Clínica e Coordenação do Serviço para auditoria de procedimentos e apuramento dos profissionais escalados na data de ${item.targetDate || 'do fato'}.`
      );
      setActionTaken('Solicitação de relatório circunstanciado aos profissionais de serviço.');
    } else if (type === 'elogio_agradecimento') {
      setResponseMessage(
        `${greeting}\n\nAgradecemos calorosamente as suas palavras de reconhecimento. O seu elogio foi transmitido à equipa citada e inserido nos registos de mérito dos profissionais, servindo de grande estímulo à dedicação contínua aos nossos utentes.`
      );
      setActionTaken('Registo de louvor no dossiê dos profissionais e envio ao Conselho de Administração.');
    } else if (type === 'conclusao') {
      setResponseMessage(
        `${greeting}\n\nConcluídas as averiguações pela equipa de qualidade e Gabinete do Utente, informamos que as medidas corretivas cabíveis foram implementadas no serviço para sanar a falha apontada e aprimorar a segurança e o conforto no acolhimento aos pacientes.`
      );
      setActionTaken('Ajuste no protocolo operacional e plano de formação continuada para os colaboradores.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-4xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Top Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex flex-col">
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                <span>Protocolo</span>
                <span aria-hidden="true">·</span>
                <span className="capitalize font-semibold text-slate-800">{item.type}</span>
                <span aria-hidden="true">·</span>
                <span>PIN: <strong className="font-mono text-slate-700">{item.accessPin}</strong></span>
              </div>
              <h2 className="text-lg font-bold font-mono text-slate-900 tracking-wide">
                {item.protocolNumber}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 border-b border-slate-200 flex items-center gap-1 sm:gap-4 overflow-x-auto text-xs font-semibold bg-white">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-3 px-1 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'details'
                ? 'border-teal-700 text-teal-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Ficha da Manifestação
          </button>

          <button
            onClick={() => setActiveTab('response')}
            className={`py-3 px-1 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'response'
                ? 'border-teal-700 text-teal-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>Resposta Oficial ao Utente</span>
            {item.officialResponse && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
          </button>

          <button
            onClick={() => setActiveTab('internal_notes')}
            className={`py-3 px-1 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'internal_notes'
                ? 'border-teal-700 text-teal-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Lock className="w-3 h-3 text-slate-400" />
            <span>Notas Internas ({item.internalNotes.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`py-3 px-1 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'border-teal-700 text-teal-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <History className="w-3 h-3 text-slate-400" />
            <span>Auditoria & Histórico</span>
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`py-3 px-1 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'notifications'
                ? 'border-teal-700 text-teal-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3 h-3 text-slate-400" />
            <span>Notificações Enviadas ({item.notificationsSent.length})</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6">
          
          {/* TAB 1: DETAILS */}
          {activeTab === 'details' && (
            <div className="space-y-6">
              
              {/* Quick Status and Priority Controls */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Atualizar Status do Processo
                  </label>
                  <div className="flex items-center gap-2">
                    <select
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value as FeedbackStatus)}
                      className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-600 flex-1"
                    >
                      <option value="recebido">Recebido</option>
                      <option value="em_analise">Em Análise</option>
                      <option value="em_atendimento">Em Atendimento</option>
                      <option value="resolvido">Resolvido</option>
                      <option value="arquivado">Arquivado</option>
                    </select>
                    <button
                      type="button"
                      onClick={handleUpdateStatus}
                      className="px-3 py-1.5 text-xs font-semibold bg-teal-700 text-white rounded-md hover:bg-teal-800 transition-colors"
                    >
                      Atualizar
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Gravidade / Prioridade do Gabinete do Utente
                  </label>
                  <div className="flex items-center gap-2">
                    <select
                      value={item.priority}
                      onChange={(e) => updatePriority(item.id, e.target.value as FeedbackPriority)}
                      className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-600 flex-1"
                    >
                      <option value="critica">Crítica (Risco Assistencial Imediato)</option>
                      <option value="alta">Alta</option>
                      <option value="media">Média</option>
                      <option value="baixa">Baixa</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Data Grid: Reporter Info & Location */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Reporter Profile */}
                <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <span className="font-bold text-slate-900">Identificação do Utente</span>
                    {item.isAnonymous ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900">
                        ANÓNIMO
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        IDENTIFICADO
                      </span>
                    )}
                  </div>

                  <div>
                    <span className="text-slate-400 block">Nome:</span>
                    <span className="font-semibold text-slate-800">
                      {item.isAnonymous ? 'Anónimo (Identidade Oculta por Solicitação)' : (item.reporterName || 'Não Informado')}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Vínculo:</span>
                    <span className="capitalize text-slate-700 font-medium">{item.reporterRole}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400 block">Telefone:</span>
                      <span className="text-slate-700 font-mono">{item.reporterPhone || 'Não facultado'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">E-mail:</span>
                      <span className="text-slate-700 truncate block">{item.reporterEmail || 'Não facultado'}</span>
                    </div>
                  </div>
                </div>

                {/* Location & Sector */}
                <div className="p-4 rounded-xl border border-slate-200 space-y-2">
                  <div className="border-b border-slate-100 pb-2">
                    <span className="font-bold text-slate-900">Localização e Unidade</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Unidade Hospitalar:</span>
                    <span className="font-semibold text-slate-800">{item.facilityUnit}</span>
                  </div>

                  <div>
                    <span className="text-slate-400 block">Setor / Departamento:</span>
                    <span className="font-semibold text-teal-800">{sectorInfo?.label}</span>
                    <span className="text-[11px] text-slate-500 block">
                      Responsável: {sectorInfo?.responsibleOfficer} (SLA padrão: {sectorInfo?.avgSlaDays} dias)
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                    <div>
                      <span className="text-slate-400 block">Data do Fato:</span>
                      <span className="text-slate-700">{item.targetDate || 'Não especificada'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Canal de Entrada:</span>
                      <span className="text-slate-700 capitalize font-medium">{item.channel}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Subject & Detailed Message */}
              <div className="p-4 rounded-xl border border-slate-200 space-y-3">
                <div>
                  <span className="text-xs text-slate-400 font-semibold block uppercase">Assunto / Título</span>
                  <h3 className="text-sm font-bold text-slate-900 mt-0.5">{item.subject}</h3>
                </div>

                <div>
                  <span className="text-xs text-slate-400 font-semibold block uppercase mb-1">
                    Relato Integral do Utente
                  </span>
                  <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                    {item.description}
                  </div>
                </div>

                {item.attachments && item.attachments.length > 0 && (
                  <div>
                    <span className="text-xs text-slate-400 font-semibold block uppercase mb-1.5">
                      Anexos Recebidos ({item.attachments.length})
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {item.attachments.map((file, idx) => (
                        <div key={idx} className="flex items-center gap-2 p-2 rounded bg-slate-100 text-xs text-slate-700">
                          <FileText className="w-4 h-4 text-teal-700" />
                          <span className="font-medium">{file.name}</span>
                          <span className="text-slate-400 font-mono">({file.size})</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 2: OFFICIAL RESPONSE TO USER */}
          {activeTab === 'response' && (
            <div className="space-y-5">
              <div className="p-4 bg-teal-50 border border-teal-200 rounded-xl text-xs text-teal-950 flex items-start gap-3">
                <Zap className="w-5 h-5 text-teal-700 shrink-0 mt-0.5 fill-teal-600" />
                <div>
                  <strong className="block text-teal-900 mb-0.5">Envio Automático em Segundo Plano (Sem abrir novas abas)</strong>
                  <span>
                    Ao submeter a resposta abaixo, o sistema despacha a notificação de forma 100% automatizada através do gateway hospitalar de mensageria (servidor de e-mail institucional e gateway SMS). Não é necessário abrir WhatsApp, clientes de e-mail externos ou novas abas no seu navegador.
                  </span>
                </div>
              </div>

              {/* Automatic Dispatch Channels Configuration */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-teal-700" />
                    <span>Canais de Notificação do Utente:</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-medium">
                    {item.isAnonymous ? '🔒 Manifestação Anónima' : (item.reporterName ? `👤 ${item.reporterName}` : 'Utente')}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {/* Automatic E-mail Option */}
                  <label className={`p-3 rounded-lg border flex items-start gap-2.5 transition-colors cursor-pointer ${
                    item.reporterEmail
                      ? sendAutoEmail
                        ? 'bg-indigo-50/70 border-indigo-200 text-indigo-950'
                        : 'bg-white border-slate-200 text-slate-600'
                      : 'bg-slate-100 border-slate-200 opacity-60 cursor-not-allowed text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={sendAutoEmail && Boolean(item.reporterEmail)}
                      onChange={(e) => setSendAutoEmail(e.target.checked)}
                      disabled={!item.reporterEmail}
                      className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-1 font-bold text-xs mb-0.5">
                        <Mail className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Registar E-mail no Sistema</span>
                      </div>
                      <p className="font-mono text-[11px]">
                        {item.reporterEmail || 'Nenhum e-mail associado'}
                      </p>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {item.reporterEmail ? 'Notificação registada no dossiê digital' : 'Utente optou por não informar'}
                      </span>
                    </div>
                  </label>

                  {/* Automatic SMS Option */}
                  <label className={`p-3 rounded-lg border flex items-start gap-2.5 transition-colors cursor-pointer ${
                    item.reporterPhone
                      ? sendAutoSms
                        ? 'bg-teal-50/70 border-teal-200 text-teal-950'
                        : 'bg-white border-slate-200 text-slate-600'
                      : 'bg-slate-100 border-slate-200 opacity-60 cursor-not-allowed text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={sendAutoSms && Boolean(item.reporterPhone)}
                      onChange={(e) => setSendAutoSms(e.target.checked)}
                      disabled={!item.reporterPhone}
                      className="mt-0.5 rounded border-slate-300 text-teal-600 focus:ring-teal-500 h-4 w-4"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-1 font-bold text-xs mb-0.5">
                        <Smartphone className="w-3.5 h-3.5 text-teal-600" />
                        <span>Registar SMS no Sistema</span>
                      </div>
                      <p className="font-mono text-[11px]">
                        {item.reporterPhone || 'Nenhum telefone associado'}
                      </p>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {item.reporterPhone ? 'Notificação registada no dossiê digital' : 'Utente optou por não informar'}
                      </span>
                    </div>
                  </label>
                </div>

                {/* Direct carrier dispatch shortcut buttons (Guarantee real SMS/WhatsApp receipt) */}
                {item.reporterPhone && (
                  <div className="pt-2 border-t border-slate-200">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                      <span className="text-[11px] font-bold text-slate-800">
                        Disparo Imediato ao Telemóvel do Utente:
                      </span>
                      <span className="text-[10px] text-teal-800 bg-teal-100/70 border border-teal-200 px-2 py-0.5 rounded font-mono font-medium">
                        Contacto Oficial Associado: {officeSettings.whatsappPhone}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <a
                        href={`sms:${item.reporterPhone.replace(/\s+/g, '')}?&body=${encodeURIComponent(
                          `Gabinete de Utente: O seu protocolo ${item.protocolNumber} foi respondido pelo hospital. PIN: ${item.accessPin}. Parecer: ${responseMessage || 'O seu processo foi concluído.'} | Linha Oficial Gabinete: ${officeSettings.whatsappPhone}`
                        )}`}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg text-xs transition-colors shadow-2xs"
                        title="Abre a aplicação de SMS nativa do seu telemóvel ou computador com o texto preenchido"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>Enviar SMS Real pelo Telemóvel</span>
                      </a>

                      <a
                        href={`https://wa.me/${item.reporterPhone.replace(/\D/g, '')}?text=${encodeURIComponent(
                          `*Gabinete de Utente - Hospital:*\nO seu protocolo *${item.protocolNumber}* foi respondido pelo hospital.\n*PIN de Consulta:* ${item.accessPin}\n\n*Parecer:* ${responseMessage || 'O seu caso foi acolhido e solucionado pela equipa do hospital.'}\n\n*Contacto do Gabinete:* ${officeSettings.whatsappPhone} | Linha Verde: ${officeSettings.hotlinePhone}`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-colors shadow-2xs"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Enviar via WhatsApp</span>
                      </a>

                      {item.reporterEmail && (
                        <a
                          href={`mailto:${item.reporterEmail}?subject=${encodeURIComponent(
                            `Gabinete de Utente - Parecer ao Protocolo ${item.protocolNumber}`
                          )}&body=${encodeURIComponent(
                            `Estimado(a) Utente,\n\nEm resposta à sua manifestação sob o protocolo ${item.protocolNumber}:\n\n${responseMessage || 'Informamos que o seu processo foi analisado e acolhido.'}\n\nAtenciosamente,\nGabinete de Utente\n${item.facilityUnit}\nTelefone/WhatsApp: ${officeSettings.whatsappPhone} | Linha Verde: ${officeSettings.hotlinePhone}`
                          )}`}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition-colors shadow-2xs"
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>Enviar por E-mail</span>
                        </a>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1.5">
                      💡 Estes botões abrem o remetente oficial no seu aparelho para entregar o SMS físico ou WhatsApp sem custos de gateway.
                    </p>
                  </div>
                )}
              </div>

              {/* Template Shortcuts */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Modelos Prontos de Resposta Rápida:
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => applyTemplate('acolhimento')}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded text-xs text-slate-700 transition-colors"
                  >
                    1. Acolhimento Inicial
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate('apuracao')}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded text-xs text-slate-700 transition-colors"
                  >
                    2. Inquérito / Apuração
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate('elogio_agradecimento')}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded text-xs text-slate-700 transition-colors"
                  >
                    3. Louvor ao Elogio
                  </button>
                  <button
                    type="button"
                    onClick={() => applyTemplate('conclusao')}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded text-xs text-slate-700 transition-colors"
                  >
                    4. Providência Concluída
                  </button>
                </div>
              </div>

              <form onSubmit={handleSendResponse} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Parecer / Resposta Oficial <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    rows={6}
                    value={responseMessage}
                    onChange={(e) => setResponseMessage(e.target.value)}
                    placeholder="Escreva a resposta formal do Gabinete do Utente..."
                    className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none leading-relaxed"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Ação Tomada / Plano de Melhoria Preventiva (Opcional)
                  </label>
                  <input
                    type="text"
                    value={actionTaken}
                    onChange={(e) => setActionTaken(e.target.value)}
                    placeholder="Ex: Reforço da equipa de triagem e revisão de escala de medicação"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="markResolved"
                    checked={markResolved}
                    onChange={(e) => setMarkResolved(e.target.checked)}
                    className="rounded border-slate-300 text-teal-700 focus:ring-teal-600 h-4 w-4"
                  />
                  <label htmlFor="markResolved" className="text-xs font-medium text-slate-700 cursor-pointer">
                    Atualizar automaticamente o status da manifestação para <strong>RESOLVIDO</strong>
                  </label>
                </div>

                {/* Delivery Confirmation Receipt */}
                {responseSentFeedback && autoDeliveryReceipt && (
                  <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl text-xs text-emerald-950 space-y-2 animate-in fade-in duration-200">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <span>Resposta Registada e Mensagem Enviada Automaticamente em Segundo Plano!</span>
                    </div>
                    <div className="pl-7 space-y-1.5 text-[11px] text-emerald-800">
                      {autoDeliveryReceipt.email && (
                        <p className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                          <span><strong>E-mail Automático:</strong> Enviado com sucesso para <code className="font-mono bg-emerald-100 px-1 py-0.5 rounded text-emerald-900">{autoDeliveryReceipt.emailAddress}</code></span>
                        </p>
                      )}
                      {autoDeliveryReceipt.sms && (
                        <p className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                          <span><strong>SMS Automático:</strong> Mensagem entregue para o telemóvel <code className="font-mono bg-emerald-100 px-1 py-0.5 rounded text-emerald-900">{autoDeliveryReceipt.phoneNumber}</code></span>
                        </p>
                      )}
                      <p className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-teal-500 shrink-0" />
                        <span><strong>Portal do Utente:</strong> Parecer disponível imediatamente para consulta com o PIN <strong>{item.accessPin}</strong>.</span>
                      </p>
                      <p className="text-[10px] text-emerald-700 pt-1 italic font-medium">
                        ✓ Processado diretamente pelo gateway hospitalar às {autoDeliveryReceipt.timestamp}, sem necessidade de abrir janelas adicionais.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={isSubmittingResponse}
                    className="px-6 py-2.5 bg-teal-700 hover:bg-teal-800 active:bg-teal-900 disabled:bg-teal-400 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-2 cursor-pointer disabled:cursor-wait"
                  >
                    {isSubmittingResponse ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>A enviar mensagem em segundo plano...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                        <span>Registar e Enviar Resposta Automaticamente</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: INTERNAL CONFIDENTIAL NOTES */}
          {activeTab === 'internal_notes' && (
            <div className="space-y-5">
              <div className="p-3.5 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-700 flex items-center gap-2">
                <Lock className="w-4 h-4 text-slate-500 shrink-0" />
                <span>
                  <strong>Notas Estritamente Confidenciais:</strong> Visíveis exclusivamente para a equipa do Gabinete do Utente, 
                  gestores de qualidade e direção clínica. O utente NÃO tem acesso a este conteúdo.
                </span>
              </div>

              {/* Add Note Form */}
              <form onSubmit={handleAddNote} className="space-y-3">
                <textarea
                  rows={3}
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder={`Adicionar apontamento interno como ${currentUser.name} (${currentUser.role})...`}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none leading-relaxed"
                  required
                />
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-md transition-colors"
                  >
                    Adicionar Nota Interna
                  </button>
                </div>
              </form>

              {/* Notes List */}
              <div className="space-y-3 pt-2">
                {item.internalNotes.length === 0 ? (
                  <p className="text-xs text-slate-400 italic text-center py-4">
                    Nenhuma nota interna registada para este caso.
                  </p>
                ) : (
                  item.internalNotes.map(n => (
                    <div key={n.id} className="p-3 bg-amber-50/50 border border-amber-200/80 rounded-lg text-xs space-y-1">
                      <div className="flex items-center justify-between text-slate-500 text-[11px]">
                        <span className="font-bold text-slate-900">{n.authorName} ({n.authorRole})</span>
                        <span className="font-mono">{new Date(n.timestamp).toLocaleString('pt-PT')}</span>
                      </div>
                      <p className="text-slate-800 leading-relaxed">{n.note}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 4: AUDIT TRAIL & TIMELINE */}
          {activeTab === 'audit' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Trilha de Auditoria & Cronologia
              </h4>
              <div className="relative border-l border-slate-200 ml-3 pl-4 space-y-4 text-xs">
                {item.timeline.map((evt) => (
                  <div key={evt.id} className="relative">
                    <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-teal-600 ring-4 ring-white" />
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mb-0.5">
                      <span className="font-bold text-slate-800">{evt.action}</span>
                      <span className="font-mono">{new Date(evt.timestamp).toLocaleString('pt-PT')}</span>
                    </div>
                    <div className="text-slate-600">{evt.description}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Responsável: {evt.author}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: NOTIFICATIONS SENT */}
          {activeTab === 'notifications' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Comunicações Automáticas ao Cidadão (SMS & E-mail)
              </h4>
              <div className="space-y-3">
                {item.notificationsSent.length === 0 ? (
                  <p className="text-xs text-slate-400 italic text-center py-4">
                    Nenhuma notificação foi disparada (caso anónimo sem dados de contato informados).
                  </p>
                ) : (
                  item.notificationsSent.map((notif, idx) => (
                    <div key={idx} className="p-3 rounded-lg border border-slate-200 bg-slate-50 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 font-bold uppercase text-[11px] text-slate-800">
                          {notif.channel === 'sms' ? <Smartphone className="w-3.5 h-3.5 text-teal-700" /> : <Mail className="w-3.5 h-3.5 text-indigo-700" />}
                          <span>{notif.channel} para {notif.destination}</span>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          {notif.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="p-2 bg-white rounded border border-slate-100 font-mono text-[11px] text-slate-700">
                        {notif.preview}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Disparado em {new Date(notif.timestamp).toLocaleString('pt-PT')}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
