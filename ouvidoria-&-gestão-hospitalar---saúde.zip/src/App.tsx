import React, { useState } from 'react';
import { FeedbackProvider, useFeedback } from './context/FeedbackContext';
import { Header } from './components/layout/Header';
import { PublicFeedbackForm } from './components/portal/PublicFeedbackForm';
import { ProtocolTracker } from './components/portal/ProtocolTracker';
import { ConfirmationModal } from './components/portal/ConfirmationModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { FeedbackList } from './components/admin/FeedbackList';
import { FeedbackDetailModal } from './components/admin/FeedbackDetailModal';
import { ManualEntryModal } from './components/admin/ManualEntryModal';
import { ManagerLoginModal } from './components/auth/ManagerLoginModal';
import { ReportsView } from './components/admin/ReportsView';
import { UserManagerView } from './components/admin/UserManagerView';
import { PrivacyView } from './components/privacy/PrivacyView';
import { FeedbackStatus, FeedbackType } from './types/feedback';
import { Building2, PhoneCall, ShieldCheck, RefreshCw, Lock, ArrowLeft, KeyRound, ShieldAlert } from 'lucide-react';

function AppContent() {
  const { feedbacks, resetToSampleData, isAuthenticated, currentUser } = useFeedback();

  const [currentView, setCurrentView] = useState<'portal_form' | 'portal_track' | 'admin_list' | 'admin_reports' | 'admin_users' | 'privacy'>('portal_form');
  
  // Login Modal state for managers
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Confirmation Modal state
  const [confirmationState, setConfirmationState] = useState<{
    isOpen: boolean;
    protocolNumber: string;
    accessPin: string;
  }>({
    isOpen: false,
    protocolNumber: '',
    accessPin: '',
  });

  // Protocol tracking query state
  const [trackerProtocol, setTrackerProtocol] = useState('');
  const [trackerPin, setTrackerPin] = useState('');

  // Selected feedback for admin detail modal
  const [selectedFeedbackId, setSelectedFeedbackId] = useState<string | null>(null);

  // Manual entry modal for telephone / in-person
  const [isManualEntryOpen, setIsManualEntryOpen] = useState(false);

  // Admin filter presets when clicked from dashboard
  const [adminTypeFilter, setAdminTypeFilter] = useState<FeedbackType | undefined>(undefined);
  const [adminStatusFilter, setAdminStatusFilter] = useState<FeedbackStatus | undefined>(undefined);
  const [showDashboardOverview, setShowDashboardOverview] = useState(true);

  const handleFeedbackCreated = (id: string, protocolNumber: string, accessPin: string) => {
    setConfirmationState({
      isOpen: true,
      protocolNumber,
      accessPin,
    });
  };

  const handleTrackNow = (proto: string, pin: string) => {
    setTrackerProtocol(proto);
    setTrackerPin(pin);
    setCurrentView('portal_track');
  };

  const handleManualCreated = (proto: string, pin: string) => {
    setConfirmationState({
      isOpen: true,
      protocolNumber: proto,
      accessPin: pin,
    });
  };

  const handleDashboardFilter = (type?: FeedbackType, status?: FeedbackStatus) => {
    setAdminTypeFilter(type);
    setAdminStatusFilter(status);
  };

  const handleLoginSuccess = (role?: string) => {
    if (role === 'admin') {
      setCurrentView('admin_users');
    } else {
      setCurrentView('admin_list');
    }
  };

  const activeItem = feedbacks.find(f => f.id === selectedFeedbackId) || null;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      {/* Institutional Top Bar */}
      <Header
        currentView={currentView}
        onNavigate={(view) => {
          if ((view === 'admin_list' || view === 'admin_reports' || view === 'admin_users') && !isAuthenticated) {
            setIsLoginModalOpen(true);
          } else {
            setCurrentView(view);
          }
        }}
        onOpenManualEntry={() => {
          if (!isAuthenticated) {
            setIsLoginModalOpen(true);
          } else {
            setIsManualEntryOpen(true);
          }
        }}
        onOpenLogin={() => setIsLoginModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {currentView === 'portal_form' && (
          <PublicFeedbackForm
            onSuccess={handleFeedbackCreated}
            onNavigateToTrack={() => setCurrentView('portal_track')}
          />
        )}

        {currentView === 'portal_track' && (
          <ProtocolTracker
            initialProtocol={trackerProtocol}
            initialPin={trackerPin}
            onNavigateToNew={() => setCurrentView('portal_form')}
          />
        )}

        {/* Central Admin Management: Gestão Integral & Utilizadores */}
        {currentView === 'admin_users' && (
          isAuthenticated ? (
            currentUser.role === 'admin' ? (
              <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6">
                <UserManagerView />
              </div>
            ) : (
              <div className="max-w-md mx-auto py-16 px-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center mx-auto mb-4">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold text-slate-900 mb-2">
                  Acesso Restrito ao Administrador Central
                </h2>
                <p className="text-xs text-slate-600 leading-relaxed mb-6">
                  A gestão e cadastro de gestores de gabinete é de competência exclusiva do Administrador de Sistemas de Saúde.
                </p>
                <button
                  onClick={() => setCurrentView('admin_list')}
                  className="px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
                >
                  Ir para o Painel do Gabinete
                </button>
              </div>
            )
          ) : (
            <div className="max-w-md mx-auto py-16 px-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-purple-50 border border-purple-200 text-purple-700 flex items-center justify-center mx-auto mb-4">
                <Lock className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">
                Autenticação de Administrador Necessária
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed mb-6">
                Inicie sessão com credenciais de Administrador do Sistema para gerir gestores e parâmetros.
              </p>
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors inline-flex items-center gap-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>Autenticar como Administrador</span>
              </button>
            </div>
          )
        )}

        {/* Protected Manager Panel */}
        {currentView === 'admin_list' && (
          isAuthenticated ? (
            <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase text-teal-800 tracking-wider mb-1">
                    <span>Área Restrita aos Gestores</span>
                    <span aria-hidden="true">·</span>
                    <span>Hospital Central & Geral de Quelimane</span>
                  </div>
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                    Painel de Gestão do Gabinete de Utente
                  </h1>
                  <p className="text-xs text-slate-500">
                    Sessão ativa de <strong>{currentUser.name}</strong> ({currentUser.role})
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowDashboardOverview(prev => !prev)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 transition-colors"
                  >
                    {showDashboardOverview ? 'Recolher Indicadores' : 'Exibir Indicadores Gerais'}
                  </button>
                </div>
              </div>

              {/* Dashboard Overview Cards */}
              {showDashboardOverview && (
                <AdminDashboard
                  feedbacks={feedbacks}
                  onSelectFeedback={(id) => setSelectedFeedbackId(id)}
                  onFilterChange={handleDashboardFilter}
                />
              )}

              {/* High-Density Feedback Table */}
              <FeedbackList
                feedbacks={feedbacks}
                onSelectFeedback={(id) => setSelectedFeedbackId(id)}
                onOpenManualEntry={() => setIsManualEntryOpen(true)}
                initialTypeFilter={adminTypeFilter}
                initialStatusFilter={adminStatusFilter}
              />
            </div>
          ) : (
            /* Unauthenticated Access Gate */
            <div className="max-w-md mx-auto py-16 px-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center mx-auto mb-4">
                <Lock className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">
                Acesso Restrito aos Gestores
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed mb-6">
                O painel de gestão, consulta de processos e relatórios institucionais exigem credenciais autorizadas. 
                Os utentes e acompanhantes têm acesso direto através do portal público.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => setIsLoginModalOpen(true)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>Autenticar como Gestor</span>
                </button>
                <button
                  onClick={() => setCurrentView('portal_form')}
                  className="w-full sm:w-auto px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Voltar ao Portal do Utente</span>
                </button>
              </div>
            </div>
          )
        )}

        {/* Protected Reports View */}
        {currentView === 'admin_reports' && (
          isAuthenticated ? (
            <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6">
              <ReportsView feedbacks={feedbacks} />
            </div>
          ) : (
            <div className="max-w-md mx-auto py-16 px-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center mx-auto mb-4">
                <Lock className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">
                Relatórios Institucionais Reservados
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed mb-6">
                A visualização de indicadores e memorandos executivos é reservada à equipa de gestão e bioética.
              </p>
              <button
                onClick={() => setIsLoginModalOpen(true)}
                className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors inline-flex items-center gap-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>Iniciar Sessão de Gestor</span>
              </button>
            </div>
          )
        )}

        {currentView === 'privacy' && (
          <PrivacyView />
        )}
      </main>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmationState.isOpen}
        onClose={() => setConfirmationState(prev => ({ ...prev, isOpen: false }))}
        protocolNumber={confirmationState.protocolNumber}
        accessPin={confirmationState.accessPin}
        onTrackNow={handleTrackNow}
      />

      {/* Manager Login Modal */}
      <ManagerLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />

      {/* Manual Entry Modal (Phone / In-person desk) */}
      <ManualEntryModal
        isOpen={isManualEntryOpen}
        onClose={() => setIsManualEntryOpen(false)}
        onSuccess={handleManualCreated}
      />

      {/* Feedback Detail & Response Inspection Modal */}
      <FeedbackDetailModal
        item={activeItem}
        onClose={() => setSelectedFeedbackId(null)}
      />

      {/* Institutional Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-teal-700" />
            <span className="font-semibold text-slate-800">
              Sistema de Gabinete de Utente Hospitalar · Quelimane
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <button
              onClick={() => setCurrentView('privacy')}
              className="hover:text-slate-900 transition-colors"
            >
              Lei de Proteção de Dados (Lei nº 3/2023)
            </button>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="flex items-center gap-1 text-slate-700 font-medium">
              <PhoneCall className="w-3.5 h-3.5 text-teal-700" /> Linha Verde: 800 123 456 (Gratuita)
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <button
              onClick={resetToSampleData}
              className="text-slate-400 hover:text-rose-700 transition-colors flex items-center gap-1"
              title="Restaurar dados de demonstração originais"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Restaurar Amostra</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <FeedbackProvider>
      <AppContent />
    </FeedbackProvider>
  );
}
