import React, { useState, useEffect } from 'react';
import { 
  Search, 
  CheckCircle, 
  Clock, 
  ShieldAlert, 
  Building, 
  MessageSquare, 
  Send, 
  AlertCircle,
  FileCheck,
  Calendar,
  Lock,
  Phone,
  PhoneCall,
  Smartphone,
  MapPin,
  Mail,
  User,
  ArrowRight
} from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';
import { FeedbackItem, FeedbackStatus } from '../../types/feedback';
import { HOSPITAL_SECTORS } from '../../data/mockData';

interface ProtocolTrackerProps {
  initialProtocol?: string;
  initialPin?: string;
  onNavigateToNew: () => void;
}

export const ProtocolTracker: React.FC<ProtocolTrackerProps> = ({
  initialProtocol = '',
  initialPin = '',
  onNavigateToNew,
}) => {
  const { findFeedbackByProtocol, addFollowupMessage, officeSettings } = useFeedback();

  const [protocolQuery, setProtocolQuery] = useState(initialProtocol);
  const [authQuery, setAuthQuery] = useState(initialPin);
  const [searchedItem, setSearchedItem] = useState<FeedbackItem | null>(null);
  const [searchAttempted, setSearchAttempted] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);
  const [replySuccessMessage, setReplySuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialProtocol) {
      setProtocolQuery(initialProtocol);
      if (initialPin) setAuthQuery(initialPin);
      const found = findFeedbackByProtocol(initialProtocol, initialPin);
      setSearchedItem(found);
      setSearchAttempted(true);
    }
  }, [initialProtocol, initialPin]);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!protocolQuery.trim()) return;

    const result = findFeedbackByProtocol(protocolQuery, authQuery);
    setSearchedItem(result);
    setSearchAttempted(true);
    setReplySuccessMessage(null);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchedItem || !replyText.trim()) return;

    setIsSubmittingReply(true);
    addFollowupMessage(searchedItem.id, replyText.trim());
    
    // Refresh current searched item
    setTimeout(() => {
      const refreshed = findFeedbackByProtocol(searchedItem.protocolNumber, authQuery);
      setSearchedItem(refreshed);
      setReplyText('');
      setIsSubmittingReply(false);
      setReplySuccessMessage('A sua mensagem foi enviada e vinculada ao processo com sucesso!');
      setTimeout(() => setReplySuccessMessage(null), 4000);
    }, 300);
  };

  // Helper for status progress steps
  const statusSteps: Array<{ key: FeedbackStatus; label: string; description: string }> = [
    { key: 'recebido', label: '1. Recebido', description: 'Manifestação acolhida no sistema' },
    { key: 'em_analise', label: '2. Em Análise', description: 'Triagem e qualificação inicial' },
    { key: 'em_atendimento', label: '3. Em Atendimento', description: 'Averiguação junto aos setores' },
    { key: 'resolvido', label: '4. Resolvido', description: 'Parecer conclusivo e plano de ação' },
  ];

  const getStepState = (stepKey: FeedbackStatus, currentStatus: FeedbackStatus) => {
    const order: FeedbackStatus[] = ['recebido', 'em_analise', 'em_atendimento', 'resolvido'];
    const currentIndex = order.indexOf(currentStatus === 'arquivado' ? 'resolvido' : currentStatus);
    const stepIndex = order.indexOf(stepKey);

    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'active';
    return 'upcoming';
  };

  const getSectorLabel = (sectorId: string) => {
    const s = HOSPITAL_SECTORS.find(sec => sec.id === sectorId);
    return s ? s.label : sectorId;
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      {/* Header Title */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 mb-1">
          Acompanhamento de Protocolo
        </h1>
        <p className="text-sm text-slate-600">
          Consulte o andamento da sua manifestação, veja as respostas oficiais da ouvidoria e envie esclarecimentos.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 mb-8">
        <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
          <div className="sm:col-span-6">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Número do Protocolo <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={protocolQuery}
              onChange={(e) => setProtocolQuery(e.target.value)}
              placeholder="Ex: HOSP-2026-10492"
              className="w-full px-3 py-2 text-sm font-mono uppercase border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
              required
            />
          </div>

          <div className="sm:col-span-4">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              PIN ou Telefone/E-mail (opcional)
            </label>
            <input
              type="text"
              value={authQuery}
              onChange={(e) => setAuthQuery(e.target.value)}
              placeholder="Ex: 4182 ou 84 312 9044"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
            />
          </div>

          <div className="sm:col-span-2">
            <button
              type="submit"
              className="w-full py-2 px-3 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 h-[38px]"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Consultar</span>
            </button>
          </div>
        </form>

        {/* Quick Demo Fillers */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs text-slate-500">
          <span className="font-medium text-slate-600">Exemplos rápidos para teste:</span>
          {[
            { label: 'Reclamação Urgência (HOSP-2026-10492)', proto: 'HOSP-2026-10492', pin: '4182' },
            { label: 'Elogio Enfermagem (HOSP-2026-10515)', proto: 'HOSP-2026-10515', pin: '8204' },
            { label: 'Sugestão Horários (HOSP-2026-10560)', proto: 'HOSP-2026-10560', pin: '9051' },
          ].map(sample => (
            <button
              key={sample.proto}
              type="button"
              onClick={() => {
                setProtocolQuery(sample.proto);
                setAuthQuery(sample.pin);
                const item = findFeedbackByProtocol(sample.proto, sample.pin);
                setSearchedItem(item);
                setSearchAttempted(true);
              }}
              className="text-xs text-teal-700 hover:text-teal-900 bg-teal-50 hover:bg-teal-100 px-2 py-0.5 rounded transition-colors"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Search Result */}
      {searchAttempted && !searchedItem && (
        <div className="bg-white rounded-xl border border-slate-200 p-8 text-center">
          <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-1">
            Nenhuma manifestação encontrada
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
            Não localizamos nenhum registo com o protocolo "{protocolQuery}". Verifique se digitou todos os caracteres
            corretamente ou consulte o comprovativo recebido.
          </p>
          <button
            onClick={onNavigateToNew}
            className="text-xs font-semibold text-teal-700 hover:text-teal-900"
          >
            Deseja submeter uma nova manifestação? Clique aqui &rarr;
          </button>
        </div>
      )}

      {searchedItem && (
        <div className="space-y-6">
          
          {/* Status Header Box */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                  <span>Protocolo</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">{searchedItem.type}</span>
                  <span aria-hidden="true">·</span>
                  <span>Registado em {new Date(searchedItem.createdAt).toLocaleDateString('pt-PT')}</span>
                </div>
                <div className="text-2xl font-bold font-mono tracking-wide text-slate-900">
                  {searchedItem.protocolNumber}
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-2">
                <span className={`px-3.5 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs ${
                  searchedItem.status === 'resolvido'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : searchedItem.status === 'em_atendimento' || searchedItem.status === 'em_analise'
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : searchedItem.status === 'arquivado'
                    ? 'bg-slate-200 text-slate-800 border border-slate-300'
                    : 'bg-blue-50 text-blue-800 border border-blue-200'
                }`}>
                  {searchedItem.status === 'resolvido' && <CheckCircle className="w-4 h-4 text-emerald-600" />}
                  {(searchedItem.status === 'em_atendimento' || searchedItem.status === 'em_analise') && <Clock className="w-4 h-4 text-amber-600 animate-spin" />}
                  {searchedItem.status === 'recebido' && <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />}
                  <span>
                    {searchedItem.status === 'resolvido' && 'RESOLVIDO (Concluído)'}
                    {searchedItem.status === 'em_atendimento' && 'EM ANDAMENTO (Em Tratamento)'}
                    {searchedItem.status === 'em_analise' && 'EM ANDAMENTO (Em Análise Inicial)'}
                    {searchedItem.status === 'recebido' && 'RECEBIDO (Pendente de Triagem)'}
                    {searchedItem.status === 'arquivado' && 'ARQUIVADO'}
                  </span>
                </span>
              </div>
            </div>

            {/* Explanatory Callout Banner based on Status */}
            <div className={`mt-4 p-3.5 rounded-lg text-xs flex items-start gap-2.5 ${
              searchedItem.status === 'resolvido'
                ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                : searchedItem.status === 'em_atendimento' || searchedItem.status === 'em_analise'
                ? 'bg-amber-50 text-amber-900 border border-amber-200'
                : 'bg-slate-100 text-slate-800 border border-slate-200'
            }`}>
              {searchedItem.status === 'resolvido' ? (
                <>
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block font-bold">A sua preocupação já foi RESOLVIDA.</strong>
                    <span>O Gabinete de Utente concluiu a averiguação e registou uma resposta formal com as providências adotadas no serviço. Veja o parecer oficial mais abaixo.</span>
                  </div>
                </>
              ) : (searchedItem.status === 'em_atendimento' || searchedItem.status === 'em_analise') ? (
                <>
                  <Clock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block font-bold">A sua preocupação está EM ANDAMENTO.</strong>
                    <span>A equipa do Gabinete de Utente está em contato com a Direção Clínica e o setor envolvido para apuração dos factos. Você será notificado assim que o parecer for emitido.</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-3 h-3 rounded-full bg-slate-400 shrink-0 mt-1" />
                  <div>
                    <strong className="block font-bold">A manifestação foi RECEBIDA (Pendente).</strong>
                    <span>O registo foi acolhido com sucesso e aguarda a primeira triagem técnica pelo gestor de serviço.</span>
                  </div>
                </>
              )}
            </div>

            {/* Stepper Progress */}
            <div className="py-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {statusSteps.map((step) => {
                  const state = getStepState(step.key, searchedItem.status);
                  return (
                    <div 
                      key={step.key}
                      className={`p-3 rounded-lg border text-left transition-colors ${
                        state === 'completed'
                          ? 'border-emerald-200 bg-emerald-50/50 text-emerald-900'
                          : state === 'active'
                          ? 'border-teal-500 bg-teal-50 text-teal-900 ring-1 ring-teal-500/20'
                          : 'border-slate-100 bg-slate-50/50 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        {state === 'completed' ? (
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                        ) : state === 'active' ? (
                          <Clock className="w-3.5 h-3.5 text-teal-700 animate-pulse" />
                        ) : (
                          <div className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                        )}
                        <span className="text-xs font-bold">{step.label}</span>
                      </div>
                      <p className="text-[11px] leading-tight opacity-80">
                        {step.description}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Manifestation Overview Data */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100 text-xs">
              <div>
                <span className="text-slate-500 block mb-0.5">Unidade Hospitalar & Setor:</span>
                <span className="font-semibold text-slate-800">
                  {searchedItem.facilityUnit} — {getSectorLabel(searchedItem.sector)}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block mb-0.5">Manifestante:</span>
                <span className="font-semibold text-slate-800">
                  {searchedItem.isAnonymous ? (
                    <span className="text-amber-800">Anónimo (Identidade protegida)</span>
                  ) : (
                    searchedItem.reporterName || 'Utente'
                  )}
                  {' '}({searchedItem.reporterRole})
                </span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-500 block mb-0.5">Assunto:</span>
                <span className="font-bold text-sm text-slate-900 block mb-1">
                  {searchedItem.subject}
                </span>
                <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-100 leading-relaxed whitespace-pre-line">
                  {searchedItem.description}
                </p>
              </div>
            </div>
          </div>

          {/* Official Response from Ouvidoria Section */}
          {searchedItem.officialResponse ? (
            <div className="bg-emerald-50/70 rounded-xl border border-emerald-200 p-6 shadow-xs">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                  <CheckCircle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-emerald-950">
                    Resposta Oficial do Gabinete de Utente Hospitalar
                  </h3>
                  <div className="text-[11px] text-emerald-800">
                    Emitida por {searchedItem.officialResponse.respondedBy} em{' '}
                    {new Date(searchedItem.officialResponse.respondedAt).toLocaleDateString('pt-PT')} às{' '}
                    {new Date(searchedItem.officialResponse.respondedAt).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-emerald-200/80 text-xs sm:text-sm text-slate-800 leading-relaxed mb-3">
                {searchedItem.officialResponse.message}
              </div>

              {searchedItem.officialResponse.actionTaken && (
                <div className="p-3 bg-emerald-100/60 rounded-lg text-xs text-emerald-900 border border-emerald-200">
                  <span className="font-bold block mb-0.5">Providência & Ação Preventiva Tomada:</span>
                  <span>{searchedItem.officialResponse.actionTaken}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 text-xs text-slate-600 flex items-start gap-3">
              <Clock className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-slate-800 mb-0.5">A manifestação está em tratamento</strong>
                <span>
                  A equipe responsável pelo setor está a apurar os factos e a preparar o parecer oficial.
                  Assim que for emitido, será exibido nesta página e você receberá uma notificação.
                </span>
              </div>
            </div>
          )}

          {/* Follow-up / Replies Thread */}
          {searchedItem.followupMessages && searchedItem.followupMessages.length > 0 && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                Histórico de Mensagens e Réplicas
              </h4>
              <div className="space-y-3">
                {searchedItem.followupMessages.map((msg) => (
                  <div 
                    key={msg.id}
                    className={`p-3.5 rounded-lg text-xs ${
                      msg.sender === 'utente'
                        ? 'bg-teal-50 border border-teal-200 ml-4'
                        : 'bg-slate-50 border border-slate-200 mr-4'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1 text-[11px] text-slate-500 font-medium">
                      <span>{msg.sender === 'utente' ? 'Você (Utente)' : 'Gabinete do Utente'}</span>
                      <span className="font-mono">{new Date(msg.timestamp).toLocaleString('pt-PT')}</span>
                    </div>
                    <p className="text-slate-800 leading-relaxed">{msg.message}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Institutional Contact Card for Direct Citizen Assistance */}
          <div className="bg-gradient-to-r from-teal-50 to-emerald-50 rounded-xl border border-teal-200 p-5 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold text-teal-950 flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-teal-700" />
                  <span>Linha Direta de Atendimento do Gabinete de Utente</span>
                </h4>
                <p className="text-xs text-teal-800 mt-0.5">
                  Deseja esclarecimentos verbais, falar por WhatsApp ou apoio presencial da nossa equipa?
                </p>
              </div>
              <div className="text-[11px] text-teal-800 bg-white/80 border border-teal-200 px-3 py-1 rounded-full font-medium shadow-2xs self-start">
                🕒 {officeSettings.operatingHours}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              {officeSettings.whatsappPhone && (
                <a
                  href={`https://wa.me/${officeSettings.whatsappPhone.replace(/\D/g, '')}?text=${encodeURIComponent(
                    `Olá! Falamos do Utente referente ao protocolo ${searchedItem.protocolNumber}. Gostaria de solicitar apoio ou esclarecimento adicional ao Gabinete de Utente.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-colors shadow-2xs"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Falar no WhatsApp: {officeSettings.whatsappPhone}</span>
                </a>
              )}

              {officeSettings.hotlinePhone && (
                <a
                  href={`tel:${officeSettings.hotlinePhone}`}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-lg text-xs transition-colors shadow-2xs"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Linha Verde: {officeSettings.hotlinePhone}</span>
                </a>
              )}

              {officeSettings.officialEmail && (
                <a
                  href={`mailto:${officeSettings.officialEmail}?subject=${encodeURIComponent(
                    `Esclarecimento sobre o Protocolo ${searchedItem.protocolNumber}`
                  )}`}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-bold rounded-lg text-xs transition-colors shadow-2xs"
                >
                  <Mail className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{officeSettings.officialEmail}</span>
                </a>
              )}
            </div>

            {officeSettings.locationOffice && (
              <p className="text-[11px] text-teal-900/80 flex items-center gap-1.5 pt-1">
                <MapPin className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                <span>Atendimento presencial: <strong>{officeSettings.locationOffice}</strong></span>
              </p>
            )}
          </div>

          {/* Patient Clarification / Reply Input */}
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <h4 className="text-sm font-bold text-slate-900 mb-1 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-teal-700" />
              <span>Enviar Esclarecimento ou Comentário Adicional</span>
            </h4>
            <p className="text-xs text-slate-500 mb-3">
              Precisa adicionar mais informações ao processo ou enviar réplica à resposta do Gabinete do Utente?
            </p>

            <form onSubmit={handleSendReply} className="space-y-3">
              <textarea
                rows={3}
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Escreva a sua mensagem aqui..."
                className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none leading-relaxed"
                required
              />

              {replySuccessMessage && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>{replySuccessMessage}</span>
                </div>
              )}

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmittingReply || !replyText.trim()}
                  className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmittingReply ? 'A enviar...' : 'Enviar Mensagem'}</span>
                </button>
              </div>
            </form>
          </div>

        </div>
      )}
    </div>
  );
};
