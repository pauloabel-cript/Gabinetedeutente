import React, { useState } from 'react';
import { 
  AlertCircle, 
  Lightbulb, 
  Heart, 
  Upload, 
  X, 
  ShieldCheck, 
  Clock, 
  Building, 
  UserCheck, 
  Send, 
  FileCheck,
  Info
} from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';
import { HOSPITAL_SECTORS, HOSPITAL_UNITS } from '../../data/mockData';
import { FeedbackType, HospitalSector, ReporterRole, Attachment } from '../../types/feedback';
import heroImage from '../../assets/images/hero_hospital_atrium_1790837523983.jpg';

interface PublicFeedbackFormProps {
  onSuccess: (feedbackId: string, protocolNumber: string, accessPin: string) => void;
  onNavigateToTrack: () => void;
}

export const PublicFeedbackForm: React.FC<PublicFeedbackFormProps> = ({ onSuccess, onNavigateToTrack }) => {
  const { createFeedback } = useFeedback();

  const [feedbackType, setFeedbackType] = useState<FeedbackType>('reclamacao');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [reporterName, setReporterName] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');
  const [reporterRole, setReporterRole] = useState<ReporterRole>('paciente');
  
  const [facilityUnit, setFacilityUnit] = useState(HOSPITAL_UNITS[0]);
  const [sector, setSector] = useState<HospitalSector>('triagem_urgencia');
  const [targetDate, setTargetDate] = useState(new Date().toISOString().split('T')[0]);
  const [targetTime, setTargetTime] = useState('10:00');
  
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Simulated file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newAttachments: Attachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const sizeFormatted = file.size > 1024 * 1024 
        ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` 
        : `${Math.round(file.size / 1024)} KB`;
      
      newAttachments.push({
        name: file.name,
        size: sizeFormatted,
        type: file.type || 'document',
      });
    }

    setAttachments(prev => [...prev, ...newAttachments]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!subject.trim()) {
      setValidationError('Por favor, informe o resumo ou assunto da manifestação.');
      return;
    }

    if (!description.trim() || description.trim().length < 15) {
      setValidationError('Por favor, descreva detalhadamente a situação (mínimo de 15 caracteres).');
      return;
    }

    if (!isAnonymous && !reporterName.trim()) {
      setValidationError('Por favor, informe o seu nome ou selecione a opção de manifestação anónima.');
      return;
    }

    if (!acceptedTerms) {
      setValidationError('É necessário aceitar os termos de consentimento e proteção de dados para submeter.');
      return;
    }

    setIsSubmitting(true);

    try {
      const item = createFeedback({
        type: feedbackType,
        isAnonymous,
        reporterName: isAnonymous ? undefined : reporterName.trim(),
        reporterPhone: reporterPhone.trim() || undefined,
        reporterEmail: reporterEmail.trim() || undefined,
        reporterRole,
        facilityUnit,
        sector,
        subject: subject.trim(),
        description: `${description.trim()}${targetTime ? ` (Ocorrido por volta das ${targetTime})` : ''}`,
        targetDate,
        attachments,
      });

      setIsSubmitting(false);
      onSuccess(item.id, item.protocolNumber, item.accessPin);
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
      setValidationError('Ocorreu um erro ao registar a manifestação. Tente novamente.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      {/* Visual Hospital Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden mb-8 border border-slate-200 shadow-sm bg-slate-900 text-white">
        <div className="absolute inset-0 z-0 opacity-40">
          <img 
            src={heroImage} 
            alt="Recepção e Instalações Hospitalares" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="relative z-10 p-6 sm:p-8 md:p-10 max-w-2xl">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-300 mb-2">
            <span>Canal Oficial de Escuta do Utente</span>
            <span aria-hidden="true">·</span>
            <span>Instituição de Saúde</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Gabinete de Utente Hospitalar
          </h1>
          <p className="text-sm sm:text-base text-slate-200 leading-relaxed mb-4">
            A sua voz fortalece os cuidados de saúde. Registe reclamações, sugestões ou elogios sobre 
            o atendimento, higiene, corpo clínico ou serviços. Cada manifestação gera um protocolo 
            único para acompanhamento transparente.
          </p>
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-teal-400" /> Opção de Anonimato Total
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-teal-400" /> Resposta Inicial em até 48h
            </span>
          </div>
        </div>
      </div>

      {/* Main Form Container */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 sm:p-8">
        <form onSubmit={handleSubmit} className="space-y-8">
          
          {/* Section 1: Type Selection (Reclamação, Sugestão, Elogio) */}
          <div>
            <label className="block text-sm font-bold text-slate-900 mb-3">
              1. Selecione o Tipo de Manifestação <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Reclamação */}
              <button
                type="button"
                onClick={() => setFeedbackType('reclamacao')}
                className={`p-4 rounded-xl border text-left transition-all relative ${
                  feedbackType === 'reclamacao'
                    ? 'border-rose-500 bg-rose-50/60 ring-2 ring-rose-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                    feedbackType === 'reclamacao' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-rose-600'
                  }`}>
                    <AlertCircle className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-sm text-slate-900">Reclamação</span>
                </div>
                <p className="text-xs text-slate-500 leading-normal">
                  Insatisfação com tempos de espera, conduta, atendimento ou instalações.
                </p>
              </button>

              {/* Sugestão */}
              <button
                type="button"
                onClick={() => setFeedbackType('sugestao')}
                className={`p-4 rounded-xl border text-left transition-all relative ${
                  feedbackType === 'sugestao'
                    ? 'border-indigo-500 bg-indigo-50/60 ring-2 ring-indigo-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                    feedbackType === 'sugestao' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-indigo-600'
                  }`}>
                    <Lightbulb className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-sm text-slate-900">Sugestão</span>
                </div>
                <p className="text-xs text-slate-500 leading-normal">
                  Proposta prática de melhoria em fluxos, equipamentos ou acolhimento.
                </p>
              </button>

              {/* Elogio */}
              <button
                type="button"
                onClick={() => setFeedbackType('elogio')}
                className={`p-4 rounded-xl border text-left transition-all relative ${
                  feedbackType === 'elogio'
                    ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-600/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                    feedbackType === 'elogio' ? 'bg-teal-700 text-white' : 'bg-slate-100 text-teal-700'
                  }`}>
                    <Heart className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-sm text-slate-900">Elogio</span>
                </div>
                <p className="text-xs text-slate-500 leading-normal">
                  Reconhecimento pela dedicação de médicos, enfermeiros e equipes.
                </p>
              </button>
            </div>
          </div>

          {/* Section 2: Manifestante & Anonymity */}
          <div className="border-t border-slate-100 pt-6">
            <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
              <label className="text-sm font-bold text-slate-900">
                2. Identificação do Manifestante
              </label>
              
              {/* Anonymous Toggle */}
              <label className="inline-flex items-center gap-2 cursor-pointer bg-slate-100 hover:bg-slate-200/80 px-3 py-1.5 rounded-lg transition-colors">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="rounded border-slate-300 text-teal-700 focus:ring-teal-600 h-4 w-4"
                />
                <span className="text-xs font-semibold text-slate-800">
                  Desejo manter o meu anonimato
                </span>
              </label>
            </div>

            {isAnonymous ? (
              <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2.5 mb-4">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <strong>Modo Anónimo Ativado:</strong> O seu nome não será revelado aos profissionais nem aos setores envolvidos.
                  Você poderá acompanhar as respostas e o desfecho exclusivamente através do <strong>Número do Protocolo</strong> e <strong>PIN</strong> gerados ao submeter.
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nome Completo <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={reporterName}
                    onChange={(e) => setReporterName(e.target.value)}
                    placeholder="Ex: Teresa da Conceição"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                    required={!isAnonymous}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Telefone (SMS de notificação)
                  </label>
                  <input
                    type="tel"
                    value={reporterPhone}
                    onChange={(e) => setReporterPhone(e.target.value)}
                    placeholder="+258 84 000 0000"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    E-mail Pessoal (para atualizações e comprovativo)
                  </label>
                  <input
                    type="email"
                    value={reporterEmail}
                    onChange={(e) => setReporterEmail(e.target.value)}
                    placeholder="ex: pauloantonio388@gmail.com"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                  />
                </div>
              </div>
            )}

            {/* Perfil do Manifestante */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Vínculo com o Hospital
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: 'paciente', label: 'Paciente / Utente' },
                  { id: 'familiar', label: 'Familiar / Acomp.' },
                  { id: 'funcionario', label: 'Funcionário / Colab.' },
                  { id: 'visitante', label: 'Visitante' },
                  { id: 'outro', label: 'Outro' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setReporterRole(item.id as ReporterRole)}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border text-center transition-colors truncate ${
                      reporterRole === item.id
                        ? 'border-teal-600 bg-teal-50 text-teal-900 font-semibold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section 3: Sector & Location */}
          <div className="border-t border-slate-100 pt-6">
            <label className="block text-sm font-bold text-slate-900 mb-3">
              3. Unidade Hospitalar, Setor e Data do Fato
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unidade Hospitalar <span className="text-red-500">*</span>
                </label>
                <select
                  value={facilityUnit}
                  onChange={(e) => setFacilityUnit(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none bg-white"
                >
                  {HOSPITAL_UNITS.map(unit => (
                    <option key={unit} value={unit}>{unit}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Área / Setor Relacionado <span className="text-red-500">*</span>
                </label>
                <select
                  value={sector}
                  onChange={(e) => setSector(e.target.value as HospitalSector)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none bg-white"
                >
                  {HOSPITAL_SECTORS.map(sec => (
                    <option key={sec.id} value={sec.id}>{sec.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Data do Ocorrido
                </label>
                <input
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Horário Aproximado
                </label>
                <input
                  type="time"
                  value={targetTime}
                  onChange={(e) => setTargetTime(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Detailed Message */}
          <div className="border-t border-slate-100 pt-6">
            <label className="block text-sm font-bold text-slate-900 mb-3">
              4. Descrição da Situação
            </label>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Assunto / Resumo <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Ex: Demora na entrega de exames na Urgência"
                  maxLength={120}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
                  required
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-slate-700">
                    Descrição Detalhada <span className="text-red-500">*</span>
                  </label>
                  <span className="text-xs text-slate-400 font-mono">
                    {description.length} caracteres
                  </span>
                </div>
                <textarea
                  rows={5}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Relate com clareza o que aconteceu, nomes de profissionais citados (se aplicável), dificuldades encontradas ou aspectos que merecem destaque..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none leading-relaxed"
                  required
                />
              </div>

              {/* Attachments Upload */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Anexar Comprovativos ou Fotos (Opcional)
                </label>
                <div className="flex items-center gap-3">
                  <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-300 transition-colors">
                    <Upload className="w-3.5 h-3.5 text-slate-600" />
                    <span>Selecionar Ficheiros</span>
                    <input
                      type="file"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                      accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                    />
                  </label>
                  <span className="text-xs text-slate-500">
                    PDF, JPG, PNG até 5MB cada (ex: faturas, receitas, fotos)
                  </span>
                </div>

                {attachments.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {attachments.map((file, idx) => (
                      <div
                        key={idx}
                        className="inline-flex items-center gap-2 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded text-xs text-slate-700"
                      >
                        <FileCheck className="w-3.5 h-3.5 text-teal-600" />
                        <span className="max-w-[180px] truncate">{file.name}</span>
                        <span className="text-slate-400 font-mono">({file.size})</span>
                        <button
                          type="button"
                          onClick={() => removeAttachment(idx)}
                          className="text-slate-400 hover:text-rose-600"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Section 5: Legal & Privacy Consent */}
          <div className="border-t border-slate-100 pt-6">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptedTerms}
                  onChange={(e) => setAcceptedTerms(e.target.checked)}
                  className="rounded border-slate-300 text-teal-700 focus:ring-teal-600 h-4 w-4 mt-0.5"
                  required
                />
                <span className="text-xs text-slate-600 leading-relaxed">
                  Declaro que as informações prestadas são verídicas. Estou ciente de que os dados serão tratados 
                  pela equipa do Gabinete do Utente em estrita conformidade com as normas éticas de saúde e com a 
                  <strong> Lei de Proteção de Dados Pessoais de Moçambique (Lei nº 3/2023)</strong>, garantindo o sigilo, 
                  confidencialidade e não retaliação ao utente.
                </span>
              </label>
            </div>
          </div>

          {/* Validation error message */}
          {validationError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Form Actions */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              type="button"
              onClick={onNavigateToTrack}
              className="text-xs font-semibold text-slate-600 hover:text-teal-800 transition-colors"
            >
              Já possui um protocolo? Clique aqui para consultar o status &rarr;
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto px-6 py-2.5 bg-teal-700 hover:bg-teal-800 active:bg-teal-900 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <span>A submeter...</span>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submeter Manifestação & Obter Protocolo</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
