import React, { useState } from 'react';
import { X, PhoneCall, UserCheck, AlertCircle, Heart, Lightbulb, Send, Check } from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';
import { HOSPITAL_SECTORS, HOSPITAL_UNITS } from '../../data/mockData';
import { FeedbackPriority, FeedbackType, HospitalSector, IntakeChannel, ReporterRole } from '../../types/feedback';

interface ManualEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (protocolNumber: string, accessPin: string) => void;
}

export const ManualEntryModal: React.FC<ManualEntryModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { createFeedback } = useFeedback();

  const [channel, setChannel] = useState<IntakeChannel>('telefone');
  const [feedbackType, setFeedbackType] = useState<FeedbackType>('reclamacao');
  const [priority, setPriority] = useState<FeedbackPriority>('media');
  
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [reporterName, setReporterName] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');
  const [reporterEmail, setReporterEmail] = useState('');
  const [reporterRole, setReporterRole] = useState<ReporterRole>('paciente');

  const [facilityUnit, setFacilityUnit] = useState(HOSPITAL_UNITS[0]);
  const [sector, setSector] = useState<HospitalSector>('triagem_urgencia');
  const [targetDate, setTargetDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [callerNotes, setCallerNotes] = useState('');
  
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!subject.trim()) {
      setError('Por favor, informe o assunto da manifestação.');
      return;
    }

    if (!description.trim()) {
      setError('Por favor, insira o relato detalhado feito pelo utente.');
      return;
    }

    const fullDescription = callerNotes.trim()
      ? `${description.trim()}\n\n[Registo Interno de Operador]: ${callerNotes.trim()}`
      : description.trim();

    const created = createFeedback({
      type: feedbackType,
      isAnonymous,
      reporterName: isAnonymous ? undefined : reporterName.trim(),
      reporterPhone: reporterPhone.trim() || undefined,
      reporterEmail: reporterEmail.trim() || undefined,
      reporterRole,
      facilityUnit,
      sector,
      subject: subject.trim(),
      description: fullDescription,
      priority,
      channel,
      targetDate,
    });

    onSuccess(created.protocolNumber, created.accessPin);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PhoneCall className="w-5 h-5 text-teal-400" />
            <div>
              <h2 className="text-base font-bold">Registo Manual de Atendimento</h2>
              <p className="text-xs text-slate-300">
                Lançamento direto de telefonemas da Linha Verde ou atendimento presencial ao balcão
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-xs">
          
          {/* Channel Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5">
              Canal de Atendimento <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setChannel('telefone')}
                className={`p-3 rounded-lg border text-left transition-all ${
                  channel === 'telefone'
                    ? 'border-teal-700 bg-teal-50 text-teal-900 font-bold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <PhoneCall className="w-4 h-4 text-teal-700" />
                  <span>Linha Verde Telefónica</span>
                </div>
                <div className="text-[11px] font-normal text-slate-500">
                  Chamada recebida pela central do gabinete de utente
                </div>
              </button>

              <button
                type="button"
                onClick={() => setChannel('presencial')}
                className={`p-3 rounded-lg border text-left transition-all ${
                  channel === 'presencial'
                    ? 'border-teal-700 bg-teal-50 text-teal-900 font-bold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <UserCheck className="w-4 h-4 text-teal-700" />
                  <span>Balcão / Presencial</span>
                </div>
                <div className="text-[11px] font-normal text-slate-500">
                  Utente presente no Gabinete do Utente
                </div>
              </button>
            </div>
          </div>

          {/* Type & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tipo de Feedback</label>
              <select
                value={feedbackType}
                onChange={(e) => setFeedbackType(e.target.value as FeedbackType)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="reclamacao">Reclamação</option>
                <option value="sugestao">Sugestão</option>
                <option value="elogio">Elogio</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Prioridade</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as FeedbackPriority)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="critica">Crítica (Risco imediato)</option>
                <option value="alta">Alta</option>
                <option value="media">Média</option>
                <option value="baixa">Baixa</option>
              </select>
            </div>
          </div>

          {/* Manifestante */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800">Dados do Utente</span>
              <label className="inline-flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="rounded border-slate-300 text-teal-700"
                />
                <span className="text-[11px] font-medium text-slate-700">Utente pediu anonimato</span>
              </label>
            </div>

            {!isAnonymous && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-0.5">Nome</label>
                  <input
                    type="text"
                    value={reporterName}
                    onChange={(e) => setReporterName(e.target.value)}
                    placeholder="Nome completo"
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-0.5">Telefone</label>
                  <input
                    type="tel"
                    value={reporterPhone}
                    onChange={(e) => setReporterPhone(e.target.value)}
                    placeholder="+258..."
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-0.5">E-mail</label>
                  <input
                    type="email"
                    value={reporterEmail}
                    onChange={(e) => setReporterEmail(e.target.value)}
                    placeholder="email@..."
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Location & Sector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Unidade Hospitalar</label>
              <select
                value={facilityUnit}
                onChange={(e) => setFacilityUnit(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
              >
                {HOSPITAL_UNITS.map(u => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Setor Relacionado</label>
              <select
                value={sector}
                onChange={(e) => setSector(e.target.value as HospitalSector)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
              >
                {HOSPITAL_SECTORS.map(s => (
                  <option key={s.id} value={s.id}>{s.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Subject & Description */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Assunto do Relato <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Ex: Queixa sobre falta de insumos no posto de enfermagem"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Relato do Utente <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descreva o que o utente relatou..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Observações do Atendente / Triagem Rápida (Opcional)
              </label>
              <input
                type="text"
                value={callerNotes}
                onChange={(e) => setCallerNotes(e.target.value)}
                placeholder="Ex: Utente falava calmamente, portador de receita médica nº 401..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {error && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Footer Action */}
          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold bg-teal-700 hover:bg-teal-800 text-white rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Emitir Protocolo e Gravar</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
