import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  FeedbackItem, 
  FeedbackStatus, 
  FeedbackPriority, 
  FeedbackType, 
  HospitalSector, 
  IntakeChannel, 
  ReporterRole, 
  Attachment,
  SystemUser,
  UserRole,
  AuditLogEntry,
  OfficeContactSettings
} from '../types/feedback';
import { INITIAL_FEEDBACKS, HOSPITAL_UNITS } from '../data/mockData';

export type StaffUser = SystemUser;

export const INITIAL_USERS: SystemUser[] = [
  {
    id: 'u0',
    name: 'Paulo António',
    email: 'pauloantonio388@gmail.com',
    password: '123',
    role: 'admin',
    title: 'Administrador Geral de Sistemas',
    assignedHospital: 'Direção Geral / Todos os Hospitais de Quelimane',
    phone: '+258 84 000 1122',
    isActive: true,
    createdAt: '2026-09-01T08:00:00Z',
  },
  { 
    id: 'u1', 
    name: 'Dra. Maria Mondlane', 
    email: 'dra.maria@saude.gov.mz',
    password: '123',
    role: 'gestor', 
    title: 'Responsável Geral do Gabinete', 
    assignedHospital: 'Hospital Central & Geral de Quelimane',
    phone: '+258 84 123 4567',
    isActive: true,
    createdAt: '2026-09-10T09:00:00Z',
  },
  { 
    id: 'u2', 
    name: 'Dr. Tomás Nhaca', 
    email: 'dr.tomas@saude.gov.mz',
    password: '123',
    role: 'gestor', 
    title: 'Gestor da Qualidade & Bioética', 
    assignedHospital: 'Hospital Central de Quelimane',
    phone: '+258 84 234 5678',
    isActive: true,
    createdAt: '2026-09-12T10:00:00Z',
  },
  { 
    id: 'u3', 
    name: 'Enfª. Beatriz Cossa', 
    email: 'enf.beatriz@saude.gov.mz',
    password: '123',
    role: 'gestor', 
    title: 'Auditora Clínica & Atendimento', 
    assignedHospital: 'Hospital Geral de Quelimane',
    phone: '+258 84 345 6789',
    isActive: true,
    createdAt: '2026-09-15T11:00:00Z',
  },
];

export const STAFF_USERS = INITIAL_USERS;

const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'log-1',
    timestamp: '2026-09-28T08:00:00Z',
    actorName: 'Eng. Paulo António',
    actorRole: 'admin',
    action: 'Inicialização do Sistema',
    details: 'Configuração dos parâmetros hospitalares de Quelimane e ativação do Gabinete de Utente.',
  },
  {
    id: 'log-2',
    timestamp: '2026-09-28T09:00:00Z',
    actorName: 'Eng. Paulo António',
    actorRole: 'admin',
    action: 'Atribuição de Permissões',
    details: 'Dra. Maria Mondlane habilitada como Responsável Geral do Gabinete de Utente.',
  }
];

interface FeedbackContextType {
  feedbacks: FeedbackItem[];
  users: SystemUser[];
  currentUser: SystemUser;
  setCurrentUser: (user: SystemUser) => void;
  isAuthenticated: boolean;
  loginManager: (email: string, password: string) => { success: boolean; error?: string };
  logoutManager: () => void;
  registerManager: (data: {
    name: string;
    email: string;
    password?: string;
    role: UserRole;
    title: string;
    assignedHospital: string;
    phone?: string;
  }) => { success: boolean; error?: string };
  updateManager: (id: string, updates: Partial<SystemUser>) => { success: boolean; error?: string };
  toggleManagerStatus: (id: string) => void;
  deleteManager: (id: string) => { success: boolean; error?: string };
  auditLogs: AuditLogEntry[];
  addAuditLog: (action: string, details: string) => void;
  createFeedback: (payload: {
    type: FeedbackType;
    isAnonymous: boolean;
    reporterName?: string;
    reporterPhone?: string;
    reporterEmail?: string;
    reporterRole: ReporterRole;
    facilityUnit: string;
    sector: HospitalSector;
    subject: string;
    description: string;
    priority?: FeedbackPriority;
    channel?: IntakeChannel;
    targetDate?: string;
    attachments?: Attachment[];
  }) => FeedbackItem;
  updateStatus: (id: string, newStatus: FeedbackStatus, changeReason?: string) => void;
  updatePriority: (id: string, newPriority: FeedbackPriority) => void;
  addInternalNote: (id: string, noteText: string) => void;
  sendOfficialResponse: (
    id: string, 
    message: string, 
    actionTaken?: string, 
    updateStatusToResolved?: boolean,
    channelOptions?: { sendEmail?: boolean; sendSms?: boolean }
  ) => void;
  addFollowupMessage: (id: string, message: string) => void;
  findFeedbackByProtocol: (protocol: string, pinOrContact?: string) => FeedbackItem | null;
  resetToSampleData: () => void;
  officeSettings: OfficeContactSettings;
  updateOfficeSettings: (updates: Partial<OfficeContactSettings>) => void;
}

const STORAGE_KEY = 'hospital_feedback_system_quelimane_v2';
const AUTH_STORAGE_KEY = 'hospital_manager_auth_v1';
const USERS_STORAGE_KEY = 'hospital_system_users_v2';
const AUDIT_STORAGE_KEY = 'hospital_system_audit_v2';
const SETTINGS_STORAGE_KEY = 'hospital_office_settings_v3';

const DEFAULT_OFFICE_SETTINGS: OfficeContactSettings = {
  hotlinePhone: '800 123 456',
  whatsappPhone: '+258 84 123 4567',
  mobileSmsPhone: '+258 84 123 4567',
  officialEmail: 'gabinete.utente@hospital.gov.mz',
  operatingHours: 'Segunda a Sexta-feira, das 07h30 às 15h30',
  locationOffice: 'Hospital Central & Geral de Quelimane (Gabinete de Atendimento ao Utente)',
  smsProvider: 'manual_sim',
  smsApiKey: '',
  androidGatewayUrl: '',
  smsSenderId: 'HCQ-SAUDE',
  slaHours: '48',
  slaMaxDays: '7',
};

const FeedbackContext = createContext<FeedbackContextType | undefined>(undefined);

export const FeedbackProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed: FeedbackItem[] = JSON.parse(stored);
        return parsed.map(item => {
          if (!HOSPITAL_UNITS.includes(item.facilityUnit)) {
            return {
              ...item,
              facilityUnit: item.facilityUnit?.toLowerCase().includes('geral') || item.facilityUnit?.toLowerCase().includes('chamanculo')
                ? 'Hospital Geral de Quelimane'
                : 'Hospital Central de Quelimane',
            };
          }
          return item;
        });
      }
    } catch (e) {
      console.error('Failed to parse stored feedbacks', e);
    }
    return INITIAL_FEEDBACKS;
  });

  const [users, setUsers] = useState<SystemUser[]>(() => {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((u: SystemUser) => {
            if (u.id === 'u0' || u.email.includes('admin@saude')) {
              return {
                ...u,
                name: 'Paulo António',
                email: 'pauloantonio388@gmail.com',
                title: 'Administrador Geral de Sistemas',
              };
            }
            return u;
          });
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_USERS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    try {
      const stored = localStorage.getItem(AUDIT_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_AUDIT_LOGS;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem(AUTH_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });

  const [currentUser, setCurrentUser] = useState<SystemUser>(() => {
    try {
      const activeId = localStorage.getItem('hospital_active_manager_id');
      const found = users.find(u => u.id === activeId);
      if (found) return found;
    } catch {}
    return users[0];
  });

  // Keep users updated in localStorage
  useEffect(() => {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (e) {
      console.error(e);
    }
  }, [users]);

  // Keep audit logs updated in localStorage
  useEffect(() => {
    try {
      localStorage.setItem(AUDIT_STORAGE_KEY, JSON.stringify(auditLogs));
    } catch (e) {
      console.error(e);
    }
  }, [auditLogs]);

  const [officeSettings, setOfficeSettings] = useState<OfficeContactSettings>(() => {
    try {
      const stored = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_OFFICE_SETTINGS, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_OFFICE_SETTINGS;
  });

  const updateOfficeSettings = (updates: Partial<OfficeContactSettings>) => {
    setOfficeSettings(prev => {
      const updated = { ...prev, ...updates };
      try {
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
    addAuditLog(
      'Atualização de Contactos',
      `Administrador ${currentUser.name} atualizou a parametrização do Gabinete (WhatsApp/SMS: ${updates.whatsappPhone || officeSettings.whatsappPhone}, Linha Verde: ${updates.hotlinePhone || officeSettings.hotlinePhone}).`
    );
  };

  const addAuditLog = (action: string, details: string) => {
    const newEntry: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actorName: currentUser ? currentUser.name : 'Sistema',
      actorRole: currentUser ? currentUser.role : 'sistema',
      action,
      details,
    };
    setAuditLogs(prev => [newEntry, ...prev.slice(0, 99)]);
  };

  const loginManager = (email: string, password: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const user = users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      return { success: false, error: 'Utilizador não encontrado. Verifique o e-mail inserido.' };
    }
    if (!user.isActive) {
      return { success: false, error: 'Esta conta foi desativada pelo Administrador do Sistema. Contacte o suporte.' };
    }
    if (user.password && user.password !== password) {
      return { success: false, error: 'Palavra-passe incorreta. Verifique os dados e tente novamente.' };
    }

    setCurrentUser(user);
    setIsAuthenticated(true);
    try {
      localStorage.setItem(AUTH_STORAGE_KEY, 'true');
      localStorage.setItem('hospital_active_manager_id', user.id);
    } catch (e) {
      console.error(e);
    }
    addAuditLog('Login no Sistema', `${user.name} (${user.role === 'admin' ? 'Administrador Central' : 'Gestor'}) iniciou sessão.`);
    return { success: true };
  };

  const logoutManager = () => {
    addAuditLog('Sessão Terminada', `${currentUser.name} encerrou a sessão no sistema.`);
    setIsAuthenticated(false);
    try {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    } catch (e) {
      console.error(e);
    }
  };

  const registerManager = (data: {
    name: string;
    email: string;
    password?: string;
    role: UserRole;
    title: string;
    assignedHospital: string;
    phone?: string;
  }) => {
    const cleanEmail = data.email.trim().toLowerCase();
    if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'Já existe um gestor registado com este endereço de e-mail.' };
    }

    const newUser: SystemUser = {
      id: `u-${Date.now()}`,
      name: data.name.trim(),
      email: cleanEmail,
      password: data.password?.trim() || '123',
      role: data.role,
      title: data.title.trim(),
      assignedHospital: data.assignedHospital,
      phone: data.phone?.trim() || undefined,
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    setUsers(prev => [...prev, newUser]);
    addAuditLog('Registo de Gestor', `Administrador ${currentUser.name} cadastrou o gestor ${newUser.name} (${newUser.title}) para ${newUser.assignedHospital}.`);
    return { success: true };
  };

  const updateManager = (id: string, updates: Partial<SystemUser>) => {
    setUsers(prev => prev.map(u => {
      if (u.id !== id) return u;
      const updated = { ...u, ...updates };
      if (currentUser.id === id) {
        setCurrentUser(updated);
      }
      return updated;
    }));
    addAuditLog('Atualização de Gestor', `Administrador ${currentUser.name} atualizou o cadastro do utilizador ID ${id}.`);
    return { success: true };
  };

  const toggleManagerStatus = (id: string) => {
    if (id === currentUser.id) return;
    setUsers(prev => prev.map(u => {
      if (u.id !== id) return u;
      const nextActive = !u.isActive;
      addAuditLog('Alteração de Estado', `Conta de ${u.name} foi ${nextActive ? 'ativada' : 'desativada'} pelo Administrador.`);
      return { ...u, isActive: nextActive };
    }));
  };

  const deleteManager = (id: string) => {
    if (id === currentUser.id) {
      return { success: false, error: 'Não é permitido eliminar a sua própria conta de administrador atualmente em sessão.' };
    }
    const target = users.find(u => u.id === id);
    if (!target) return { success: false, error: 'Gestor não encontrado no sistema.' };

    const remainingUsers = users.filter(u => u.id !== id);
    setUsers(remainingUsers);
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(remainingUsers));
    } catch (e) {
      console.error('Failed to persist users after deletion', e);
    }
    addAuditLog('Exclusão de Gestor', `Administrador ${currentUser.name} eliminou a conta de ${target.name} (${target.email}).`);
    return { success: true };
  };

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(feedbacks));
    } catch (e) {
      console.error('Failed to save feedbacks to localStorage', e);
    }
  }, [feedbacks]);

  const generateProtocolNumber = (): string => {
    const year = new Date().getFullYear();
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    return `HOSP-${year}-${randomNum}`;
  };

  const generatePin = (): string => {
    return Math.floor(1000 + Math.random() * 9000).toString();
  };

  const createFeedback: FeedbackContextType['createFeedback'] = (payload) => {
    const protocolNumber = generateProtocolNumber();
    const accessPin = generatePin();
    const now = new Date().toISOString();
    
    // Default priority based on feedback type
    let priority: FeedbackPriority = payload.priority || 'media';
    if (!payload.priority) {
      if (payload.type === 'reclamacao') priority = 'alta';
      else if (payload.type === 'elogio') priority = 'baixa';
      else priority = 'media';
    }

    const channel = payload.channel || 'web';
    const channelLabel = channel === 'web' ? 'Portal Web do Utente' : channel === 'telefone' ? 'Linha Verde Telefónica' : 'Balcão Presencial';

    const newItem: FeedbackItem = {
      id: `f-${Date.now()}`,
      protocolNumber,
      accessPin,
      type: payload.type,
      status: 'recebido',
      priority,
      channel,
      createdAt: now,
      updatedAt: now,
      targetDate: payload.targetDate || new Date().toISOString().split('T')[0],
      isAnonymous: payload.isAnonymous,
      reporterName: payload.isAnonymous ? undefined : payload.reporterName,
      reporterPhone: payload.reporterPhone,
      reporterEmail: payload.reporterEmail,
      reporterRole: payload.reporterRole,
      facilityUnit: payload.facilityUnit,
      sector: payload.sector,
      subject: payload.subject,
      description: payload.description,
      attachments: payload.attachments || [],
      internalNotes: [],
      timeline: [
        {
          id: `t-${Date.now()}`,
          timestamp: now,
          author: channel === 'web' ? 'Sistema Online' : `${currentUser.name} (${channelLabel})`,
          action: 'Manifestação Registada',
          description: `Manifestação recebida com sucesso via ${channelLabel}. Protocolo emitido para acompanhamento.`,
          isPublic: true,
        },
      ],
      notificationsSent: [],
      followupMessages: [],
    };

    // Simulate auto-notification dispatch if phone or email provided
    if (payload.reporterPhone) {
      newItem.notificationsSent.push({
        timestamp: now,
        channel: 'sms',
        destination: payload.reporterPhone,
        status: 'entregue',
        preview: `Hospital: Sua manifestação ${protocolNumber} foi recebida com sucesso. Guarde o seu PIN de acesso: ${accessPin}.`,
      });
    }

    if (payload.reporterEmail) {
      newItem.notificationsSent.push({
        timestamp: now,
        channel: 'email',
        destination: payload.reporterEmail,
        status: 'entregue',
        preview: `Confirmação de recebimento do protocolo ${protocolNumber}. Pode consultar o estado em tempo real no nosso portal com o PIN: ${accessPin}.`,
      });
    }

    setFeedbacks(prev => [newItem, ...prev]);
    return newItem;
  };

  const updateStatus = (id: string, newStatus: FeedbackStatus, changeReason?: string) => {
    const now = new Date().toISOString();
    const statusLabels: Record<FeedbackStatus, string> = {
      recebido: 'Recebido',
      em_analise: 'Em Análise',
      em_atendimento: 'Em Atendimento / Investigação',
      resolvido: 'Resolvido',
      arquivado: 'Arquivado',
    };

    setFeedbacks(prev => prev.map(item => {
      if (item.id !== id) return item;

      const newTimeline = [
        ...item.timeline,
        {
          id: `t-${Date.now()}`,
          timestamp: now,
          author: currentUser.name,
          action: `Status alterado para: ${statusLabels[newStatus]}`,
          description: changeReason || `Status atualizado pela equipa do Gabinete do Utente (${currentUser.role}).`,
          isPublic: true,
        }
      ];

      const newNotifications = [...item.notificationsSent];
      if (item.reporterPhone) {
        newNotifications.push({
          timestamp: now,
          channel: 'sms',
          destination: item.reporterPhone,
          status: 'entregue',
          preview: `Hospital: O status do protocolo ${item.protocolNumber} foi atualizado para "${statusLabels[newStatus]}".`,
        });
      }

      return {
        ...item,
        status: newStatus,
        updatedAt: now,
        timeline: newTimeline,
        notificationsSent: newNotifications,
      };
    }));
  };

  const updatePriority = (id: string, newPriority: FeedbackPriority) => {
    const now = new Date().toISOString();
    setFeedbacks(prev => prev.map(item => {
      if (item.id !== id) return item;
      return {
        ...item,
        priority: newPriority,
        updatedAt: now,
        timeline: [
          ...item.timeline,
          {
            id: `t-${Date.now()}`,
            timestamp: now,
            author: currentUser.name,
            action: `Prioridade ajustada para: ${newPriority.toUpperCase()}`,
            description: `Reclassificação de urgência realizada pela equipa de triagem.`,
            isPublic: false,
          }
        ]
      };
    }));
  };

  const addInternalNote = (id: string, noteText: string) => {
    const now = new Date().toISOString();
    setFeedbacks(prev => prev.map(item => {
      if (item.id !== id) return item;
      return {
        ...item,
        updatedAt: now,
        internalNotes: [
          ...item.internalNotes,
          {
            id: `in-${Date.now()}`,
            authorName: currentUser.name,
            authorRole: currentUser.role,
            timestamp: now,
            note: noteText,
          }
        ]
      };
    }));
  };

  const sendOfficialResponse = (
    id: string, 
    message: string, 
    actionTaken?: string, 
    updateStatusToResolved: boolean = false,
    channelOptions?: { sendEmail?: boolean; sendSms?: boolean }
  ) => {
    const now = new Date().toISOString();
    const shouldSendEmail = channelOptions ? channelOptions.sendEmail !== false : true;
    const shouldSendSms = channelOptions ? channelOptions.sendSms !== false : true;

    setFeedbacks(prev => prev.map(item => {
      if (item.id !== id) return item;

      const newStatus = updateStatusToResolved ? 'resolvido' : item.status;
      const newTimeline = [
        ...item.timeline,
        {
          id: `t-${Date.now()}`,
          timestamp: now,
          author: currentUser.name,
          action: 'Resposta Oficial Registada & Despachada',
          description: 'O Gabinete do Utente emitiu parecer formal com disparo automático em segundo plano.',
          isPublic: true,
        }
      ];

      const newNotifications = [...item.notificationsSent];
      const notifyEmailBody = `Gabinete do Utente - Hospital: O seu protocolo ${item.protocolNumber} recebeu o parecer oficial da equipa médica e de gestão:\n\n"${message}"\n\nMedidas Preventivas: ${actionTaken || 'Conformidade com protocolos clínicos.'}\n\nPode consultar a qualquer momento no portal com o seu PIN: ${item.accessPin}.`;
      const notifySmsBody = `Hospital Quelimane: Resposta ao protocolo ${item.protocolNumber}: "${message.slice(0, 110)}...". Situação: ${newStatus.toUpperCase()}. Consulte no portal com PIN: ${item.accessPin}`;

      if (item.reporterPhone && shouldSendSms) {
        newNotifications.push({
          timestamp: now,
          channel: 'sms',
          destination: item.reporterPhone,
          status: 'entregue',
          preview: notifySmsBody,
        });
      }

      if (item.reporterEmail && shouldSendEmail) {
        newNotifications.push({
          timestamp: now,
          channel: 'email',
          destination: item.reporterEmail,
          status: 'entregue',
          preview: notifyEmailBody,
        });
      }

      return {
        ...item,
        status: newStatus,
        updatedAt: now,
        officialResponse: {
          respondedAt: now,
          respondedBy: `${currentUser.name} (${currentUser.role})`,
          message,
          actionTaken,
        },
        timeline: newTimeline,
        notificationsSent: newNotifications,
      };
    }));

    addAuditLog('Resposta Oficial Emitida', `Gestor ${currentUser.name} concluiu o atendimento do protocolo ID ${id} com notificação automática.`);
  };

  const addFollowupMessage = (id: string, message: string) => {
    const now = new Date().toISOString();
    setFeedbacks(prev => prev.map(item => {
      if (item.id !== id) return item;
      return {
        ...item,
        updatedAt: now,
        followupMessages: [
          ...(item.followupMessages || []),
          {
            id: `fl-${Date.now()}`,
            sender: 'utente',
            timestamp: now,
            message,
          }
        ],
        timeline: [
          ...item.timeline,
          {
            id: `t-${Date.now()}`,
            timestamp: now,
            author: item.isAnonymous ? 'Utente (Anónimo)' : (item.reporterName || 'Utente'),
            action: 'Nova Mensagem do Utente',
            description: 'O utente enviou esclarecimentos ou réplica através do portal de acompanhamento.',
            isPublic: true,
          }
        ]
      };
    }));
  };

  const findFeedbackByProtocol = (protocol: string, pinOrContact?: string): FeedbackItem | null => {
    const cleanProtocol = protocol.trim().toUpperCase();
    const cleanAuth = pinOrContact?.trim().toLowerCase();

    return feedbacks.find(item => {
      const matchProtocol = item.protocolNumber.toUpperCase() === cleanProtocol;
      if (!matchProtocol) return false;

      if (!cleanAuth) return true;

      // Check pin
      if (item.accessPin === cleanAuth) return true;

      // Check phone or email
      if (item.reporterPhone && item.reporterPhone.replace(/\s+/g, '').includes(cleanAuth.replace(/\s+/g, ''))) return true;
      if (item.reporterEmail && item.reporterEmail.toLowerCase().includes(cleanAuth)) return true;

      return false;
    }) || null;
  };

  const resetToSampleData = () => {
    setFeedbacks(INITIAL_FEEDBACKS);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_FEEDBACKS));
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <FeedbackContext.Provider
      value={{
        feedbacks,
        users,
        currentUser,
        setCurrentUser,
        isAuthenticated,
        loginManager,
        logoutManager,
        registerManager,
        updateManager,
        toggleManagerStatus,
        deleteManager,
        auditLogs,
        addAuditLog,
        createFeedback,
        updateStatus,
        updatePriority,
        addInternalNote,
        sendOfficialResponse,
        addFollowupMessage,
        findFeedbackByProtocol,
        resetToSampleData,
        officeSettings,
        updateOfficeSettings,
      }}
    >
      {children}
    </FeedbackContext.Provider>
  );
};

export const useFeedback = () => {
  const context = useContext(FeedbackContext);
  if (!context) {
    throw new Error('useFeedback must be used within a FeedbackProvider');
  }
  return context;
};
