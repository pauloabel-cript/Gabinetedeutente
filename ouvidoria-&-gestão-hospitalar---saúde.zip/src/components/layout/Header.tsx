import React from 'react';
import { 
  Building2, 
  Search, 
  BarChart3, 
  ShieldCheck, 
  Headphones, 
  PhoneCall, 
  Lock,
  LogOut,
  UserCheck,
  Users
} from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';

interface HeaderProps {
  currentView: 'portal_form' | 'portal_track' | 'admin_list' | 'admin_reports' | 'admin_users' | 'privacy';
  onNavigate: (view: 'portal_form' | 'portal_track' | 'admin_list' | 'admin_reports' | 'admin_users' | 'privacy') => void;
  onOpenManualEntry: () => void;
  onOpenLogin: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  currentView, 
  onNavigate, 
  onOpenManualEntry,
  onOpenLogin
}) => {
  const { currentUser, setCurrentUser, isAuthenticated, logoutManager, users } = useFeedback();

  const handleLogout = () => {
    logoutManager();
    onNavigate('portal_form');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Institutional Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => onNavigate(isAuthenticated ? (currentUser.role === 'admin' ? 'admin_users' : 'admin_list') : 'portal_form')} 
            className="flex items-center gap-2.5 text-left group"
          >
            <div className={`w-9 h-9 rounded-lg text-white flex items-center justify-center font-bold text-lg shadow-sm ${
              isAuthenticated && currentUser.role === 'admin' ? 'bg-purple-800' : 'bg-teal-700'
            }`}>
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-slate-900 group-hover:text-teal-800 transition-colors">
                Gabinete de Utente Hospitalar
              </span>
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                {isAuthenticated 
                  ? (currentUser.role === 'admin' ? 'Administração Central do Sistema' : 'Painel de Gestão Hospitalar')
                  : 'Portal de Atendimento ao Cidadão'}
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {/* Public Citizen Navigation */}
          {!isAuthenticated ? (
            <>
              <button
                onClick={() => onNavigate('portal_form')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  currentView === 'portal_form'
                    ? 'text-teal-900 bg-teal-50'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Nova Manifestação
              </button>
              
              <button
                onClick={() => onNavigate('portal_track')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  currentView === 'portal_track'
                    ? 'text-teal-900 bg-teal-50'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                Consultar Protocolo
              </button>

              <button
                onClick={() => onNavigate('privacy')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  currentView === 'privacy'
                    ? 'text-teal-900 bg-teal-50'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Proteção de Dados
              </button>
            </>
          ) : (
            /* Manager Authenticated Navigation */
            <>
              {/* Exclusive Admin Tab: Gestão Integral de Gestores */}
              {currentUser.role === 'admin' && (
                <button
                  onClick={() => onNavigate('admin_users')}
                  className={`px-3 py-2 text-xs font-bold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                    currentView === 'admin_users'
                      ? 'text-purple-950 bg-purple-100 font-extrabold shadow-2xs'
                      : 'text-purple-800 hover:text-purple-950 hover:bg-purple-50'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-purple-700" />
                  Gestão de Gestores
                </button>
              )}

              <button
                onClick={() => onNavigate('admin_list')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  currentView === 'admin_list'
                    ? 'text-teal-900 bg-teal-50 font-bold'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Headphones className="w-3.5 h-3.5 text-teal-700" />
                Painel do Gabinete
              </button>

              <button
                onClick={() => onNavigate('admin_reports')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  currentView === 'admin_reports'
                    ? 'text-teal-900 bg-teal-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                Relatórios & SLA
              </button>

              <span className="text-slate-300 mx-1">|</span>

              <button
                onClick={() => onNavigate('portal_form')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  currentView === 'portal_form' || currentView === 'portal_track'
                    ? 'text-teal-900 bg-teal-50'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                }`}
                title="Visualizar a interface pública como um utente"
              >
                Ver Portal do Utente
              </button>

              <button
                onClick={() => onNavigate('privacy')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                  currentView === 'privacy'
                    ? 'text-teal-900 bg-teal-50'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Proteção de Dados
              </button>
            </>
          )}
        </nav>

        {/* Zone 3: Actions & Auth Controls */}
        <div className="flex items-center gap-2">
          {!isAuthenticated ? (
            /* Unauthenticated Citizen: Single Distinct Manager Access Button */
            <button
              onClick={onOpenLogin}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shadow-xs"
              title="Acesso com credenciais para administradores e gestores do hospital"
            >
              <Lock className="w-3.5 h-3.5 text-teal-700" />
              <span>Acesso de Gestor</span>
            </button>
          ) : (
            /* Authenticated Manager Controls */
            <>
              {/* Quick manual entry button */}
              <button
                onClick={onOpenManualEntry}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-md transition-colors whitespace-nowrap shadow-xs"
                title="Registar manifesto recebido via chamada ou atendimento presencial"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>+ Atendimento Manual</span>
              </button>

              {/* Current Staff Profile Selector with Admin Distinction */}
              <div className="relative group hidden md:block">
                <select
                  value={currentUser.id}
                  onChange={(e) => {
                    const selected = users.find(u => u.id === e.target.value);
                    if (selected) setCurrentUser(selected);
                  }}
                  className={`appearance-none border rounded-md py-1.5 pl-2.5 pr-7 text-xs font-medium focus:outline-none cursor-pointer ${
                    currentUser.role === 'admin'
                      ? 'bg-purple-50 border-purple-300 text-purple-950 font-bold focus:ring-1 focus:ring-purple-600'
                      : 'bg-slate-50 border-slate-200 text-slate-800 focus:ring-1 focus:ring-teal-600'
                  }`}
                  title="Alternar utilizador em sessão"
                >
                  {users.map((user) => (
                    <option key={user.id} value={user.id}>
                      {user.role === 'admin' ? '👑 ' : ''}{user.name} ({user.role === 'admin' ? 'Admin' : 'Gestor'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Logout Button */}
              <button
                onClick={handleLogout}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-rose-700 hover:text-rose-900 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors whitespace-nowrap border border-rose-200"
                title="Terminar sessão e regressar à área pública"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Terminar Sessão</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="lg:hidden border-t border-slate-200 bg-slate-50 px-4 py-2 flex items-center justify-between overflow-x-auto gap-2 text-xs font-medium">
        {!isAuthenticated ? (
          <>
            <button
              onClick={() => onNavigate('portal_form')}
              className={`px-2.5 py-1.5 rounded whitespace-nowrap ${currentView === 'portal_form' ? 'bg-white shadow-xs font-bold text-teal-900' : 'text-slate-600'}`}
            >
              Enviar Feedback
            </button>
            <button
              onClick={() => onNavigate('portal_track')}
              className={`px-2.5 py-1.5 rounded whitespace-nowrap ${currentView === 'portal_track' ? 'bg-white shadow-xs font-bold text-teal-900' : 'text-slate-600'}`}
            >
              Consultar Protocolo
            </button>
            <button
              onClick={() => onNavigate('privacy')}
              className={`px-2.5 py-1.5 rounded whitespace-nowrap ${currentView === 'privacy' ? 'bg-white shadow-xs font-bold text-teal-900' : 'text-slate-600'}`}
            >
              Proteção de Dados
            </button>
            <button
              onClick={onOpenLogin}
              className="px-2.5 py-1.5 rounded whitespace-nowrap bg-teal-700 text-white font-semibold flex items-center gap-1"
            >
              <Lock className="w-3 h-3" />
              <span>Gestores</span>
            </button>
          </>
        ) : (
          <>
            {currentUser.role === 'admin' && (
              <button
                onClick={() => onNavigate('admin_users')}
                className={`px-2.5 py-1.5 rounded whitespace-nowrap ${currentView === 'admin_users' ? 'bg-purple-800 text-white font-bold' : 'text-purple-900'}`}
              >
                Gestores
              </button>
            )}
            <button
              onClick={() => onNavigate('admin_list')}
              className={`px-2.5 py-1.5 rounded whitespace-nowrap ${currentView === 'admin_list' ? 'bg-white shadow-xs font-bold text-teal-900' : 'text-slate-600'}`}
            >
              Painel Gabinete
            </button>
            <button
              onClick={() => onNavigate('admin_reports')}
              className={`px-2.5 py-1.5 rounded whitespace-nowrap ${currentView === 'admin_reports' ? 'bg-white shadow-xs font-bold text-teal-900' : 'text-slate-600'}`}
            >
              Relatórios
            </button>
            <button
              onClick={() => onNavigate('portal_form')}
              className="px-2.5 py-1.5 rounded whitespace-nowrap text-slate-600"
            >
              Portal Utente
            </button>
            <button
              onClick={onOpenManualEntry}
              className="px-2.5 py-1.5 rounded whitespace-nowrap bg-teal-700 text-white font-semibold"
            >
              + Manual
            </button>
            <button
              onClick={handleLogout}
              className="px-2.5 py-1.5 rounded whitespace-nowrap text-rose-700 font-semibold"
            >
              Sair
            </button>
          </>
        )}
      </div>
    </header>
  );
};

