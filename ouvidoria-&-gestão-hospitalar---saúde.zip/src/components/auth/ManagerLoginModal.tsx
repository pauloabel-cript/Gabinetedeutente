import React, { useState } from 'react';
import { 
  Lock, 
  X, 
  ShieldCheck, 
  AlertCircle, 
  KeyRound 
} from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';

interface ManagerLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (role?: string) => void;
}

export const ManagerLoginModal: React.FC<ManagerLoginModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { loginManager, users } = useFeedback();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    const res = loginManager(email, password);
    setIsSubmitting(false);

    if (res.success) {
      const loggedUser = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
      onSuccess(loggedUser?.role);
      onClose();
    } else {
      setErrorMessage(res.error || 'Credenciais inválidas. Tente novamente.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-10 h-10 rounded-xl bg-purple-800/90 border border-purple-700 flex items-center justify-center mb-3">
            <Lock className="w-5 h-5 text-purple-200" />
          </div>

          <h2 className="text-lg font-bold tracking-tight">Acesso de Gestão & Administração</h2>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            Área restrita e autenticada para Administradores de Sistemas e Gestores do Gabinete de Utente.
          </p>
        </div>

        {/* Public Notice Banner */}
        <div className="px-6 py-2.5 bg-amber-50 border-b border-amber-200 text-xs text-amber-900 flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <p>
            <strong>É utente ou acompanhante?</strong> Não necessita de login. O registo de manifestações e acompanhamento de protocolos são de 
            <button 
              type="button" 
              onClick={onClose} 
              className="text-teal-800 font-bold underline ml-1 hover:text-teal-950"
            >
              acesso livre e público
            </button>.
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              E-mail de Acesso <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Digite o seu endereço de e-mail"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-purple-600 focus:border-purple-600 outline-none"
              required
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-700">
                Palavra-passe de Acesso <span className="text-red-500">*</span>
              </label>
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-1 focus:ring-purple-600 focus:border-purple-600 outline-none"
              required
            />
          </div>

          {errorMessage && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-2.5 px-4 bg-purple-700 hover:bg-purple-800 active:bg-purple-900 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <KeyRound className="w-4 h-4" />
            <span>{isSubmitting ? 'A verificar credenciais...' : 'Entrar no Sistema'}</span>
          </button>
        </form>

      </div>
    </div>
  );
};

