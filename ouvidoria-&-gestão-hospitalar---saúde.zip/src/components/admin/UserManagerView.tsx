import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  Building2, 
  KeyRound, 
  CheckCircle2, 
  XCircle, 
  Trash2, 
  Lock, 
  History, 
  Sliders, 
  AlertCircle,
  AlertTriangle,
  X,
  Check,
  Search,
  Settings,
  Clock,
  Sparkles,
  PhoneCall,
  MessageSquare,
  Smartphone,
  Mail,
  MapPin
} from 'lucide-react';
import { useFeedback } from '../../context/FeedbackContext';
import { SystemUser, UserRole } from '../../types/feedback';
import { HOSPITAL_UNITS } from '../../data/mockData';

export const UserManagerView: React.FC = () => {
  const { 
    users, 
    currentUser, 
    registerManager, 
    updateManager, 
    toggleManagerStatus, 
    deleteManager,
    auditLogs,
    officeSettings,
    updateOfficeSettings
  } = useFeedback();

  const [activeTab, setActiveTab] = useState<'users' | 'settings' | 'audit'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Create / Edit Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);

  // In-app Delete Confirmation Modal State (replaces blocked window.confirm)
  const [deleteTargetUser, setDeleteTargetUser] = useState<SystemUser | null>(null);
  const [actionToast, setActionToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPassword, setFormPassword] = useState('123');
  const [formRole, setFormRole] = useState<UserRole>('gestor');
  const [formTitle, setFormTitle] = useState('');
  const [formHospital, setFormHospital] = useState(HOSPITAL_UNITS[0]);
  const [formPhone, setFormPhone] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // System parameters (synchronized with officeSettings)
  const [slaHours, setSlaHours] = useState(officeSettings.slaHours || '48');
  const [slaMaxDays, setSlaMaxDays] = useState(officeSettings.slaMaxDays || '7');
  const [hotlinePhone, setHotlinePhone] = useState(officeSettings.hotlinePhone || '800 123 456');
  const [whatsappPhone, setWhatsappPhone] = useState(officeSettings.whatsappPhone || '+258 84 123 4567');
  const [officialEmail, setOfficialEmail] = useState(officeSettings.officialEmail || 'gabinete.utente@hospital.gov.mz');
  const [operatingHours, setOperatingHours] = useState(officeSettings.operatingHours || 'Segunda a Sexta-feira, das 07h30 às 15h30');
  const [locationOffice, setLocationOffice] = useState(officeSettings.locationOffice || 'Hospital Central & Geral de Quelimane (Gabinete de Atendimento ao Utente)');
  const [smsProvider, setSmsProvider] = useState<'bulksms_mz' | 'infobip' | 'twilio' | 'vodacom_api' | 'manual_sim' | 'android_gateway'>(officeSettings.smsProvider || 'manual_sim');
  const [smsApiKey, setSmsApiKey] = useState(officeSettings.smsApiKey || '');
  const [androidGatewayUrl, setAndroidGatewayUrl] = useState(officeSettings.androidGatewayUrl || '');
  const [smsSenderId, setSmsSenderId] = useState(officeSettings.smsSenderId || 'HCQ-SAUDE');
  const [savedSettingsNotice, setSavedSettingsNotice] = useState(false);

  const openCreateModal = () => {
    setEditingUserId(null);
    setFormName('');
    setFormEmail('');
    setFormPassword('123');
    setFormRole('gestor');
    setFormTitle('Técnico do Gabinete de Utente');
    setFormHospital(HOSPITAL_UNITS[0]);
    setFormPhone('');
    setFormError(null);
    setFormSuccess(null);
    setIsModalOpen(true);
  };

  const openEditModal = (user: SystemUser) => {
    setEditingUserId(user.id);
    setFormName(user.name);
    setFormEmail(user.email);
    setFormPassword(user.password || '123');
    setFormRole(user.role);
    setFormTitle(user.title);
    setFormHospital(user.assignedHospital);
    setFormPhone(user.phone || '');
    setFormError(null);
    setFormSuccess(null);
    setIsModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formName.trim() || !formEmail.trim() || !formTitle.trim()) {
      setFormError('Preencha todos os campos obrigatórios.');
      return;
    }

    if (editingUserId) {
      const res = updateManager(editingUserId, {
        name: formName.trim(),
        email: formEmail.trim().toLowerCase(),
        password: formPassword.trim() || '123',
        role: formRole,
        title: formTitle.trim(),
        assignedHospital: formHospital,
        phone: formPhone.trim() || undefined,
      });

      if (!res.success) {
        setFormError(res.error || 'Erro ao atualizar.');
        return;
      }

      setFormSuccess('Dados do utilizador atualizados com sucesso!');
      setTimeout(() => {
        setIsModalOpen(false);
      }, 1200);
    } else {
      const res = registerManager({
        name: formName.trim(),
        email: formEmail.trim().toLowerCase(),
        password: formPassword.trim() || '123',
        role: formRole,
        title: formTitle.trim(),
        assignedHospital: formHospital,
        phone: formPhone.trim() || undefined,
      });

      if (!res.success) {
        setFormError(res.error || 'Erro ao registar utilizador.');
        return;
      }

      setFormSuccess('Gestor cadastrado com sucesso e habilitado no sistema!');
      setTimeout(() => {
        setIsModalOpen(false);
      }, 1200);
    }
  };

  const handleConfirmDelete = () => {
    if (!deleteTargetUser) return;
    const res = deleteManager(deleteTargetUser.id);
    if (res.success) {
      setActionToast({
        message: `Gestor "${deleteTargetUser.name}" foi removido do sistema com sucesso.`,
        type: 'success'
      });
      setDeleteTargetUser(null);
      setTimeout(() => setActionToast(null), 3500);
    } else {
      setActionToast({
        message: res.error || 'Erro ao remover gestor.',
        type: 'error'
      });
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateOfficeSettings({
      slaHours,
      slaMaxDays,
      hotlinePhone,
      whatsappPhone,
      mobileSmsPhone: whatsappPhone,
      officialEmail,
      operatingHours,
      locationOffice,
      smsProvider,
      smsApiKey,
      androidGatewayUrl,
      smsSenderId,
    });
    setSavedSettingsNotice(true);
    setTimeout(() => setSavedSettingsNotice(false), 3500);
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.assignedHospital.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase text-purple-800 tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4 text-purple-700" />
            <span>Módulo de Governança & Administração Central</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Gestão Integral & Registo de Gestores
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Controlo centralizado de acessos, cadastro de responsáveis do Gabinete de Utente e auditoria institucional.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={openCreateModal}
            className="px-4 py-2.5 text-xs font-bold text-white bg-purple-700 hover:bg-purple-800 rounded-lg shadow-sm transition-colors flex items-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Cadastrar Novo Gestor</span>
          </button>
        </div>
      </div>

      {/* Action Feedback Toast */}
      {actionToast && (
        <div className={`p-4 rounded-xl text-xs flex items-center justify-between gap-3 shadow-xs animate-in fade-in duration-200 ${
          actionToast.type === 'success' 
            ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
            : 'bg-rose-50 border border-rose-200 text-rose-800'
        }`}>
          <div className="flex items-center gap-2">
            {actionToast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span className="font-semibold">{actionToast.message}</span>
          </div>
          <button 
            onClick={() => setActionToast(null)}
            className="text-slate-400 hover:text-slate-700 p-1 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Total de Contas
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 font-mono">{users.length}</span>
            <span className="text-xs text-slate-400">utilizadores</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Gestores Ativos
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-700 font-mono">
              {users.filter(u => u.isActive).length}
            </span>
            <span className="text-xs text-emerald-600">em operação</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Hospitais Vinculados
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-teal-800 font-mono">2</span>
            <span className="text-xs text-slate-400">Quelimane</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Auditoria & Logs
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-purple-700 font-mono">{auditLogs.length}</span>
            <span className="text-xs text-slate-400">registos</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'users'
              ? 'bg-purple-100 text-purple-900 border border-purple-200 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Gestores Cadastrados ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'settings'
              ? 'bg-purple-100 text-purple-900 border border-purple-200 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Parâmetros do Sistema & SLA</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'audit'
              ? 'bg-purple-100 text-purple-900 border border-purple-200 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Trilha de Auditoria</span>
        </button>
      </div>

      {/* TAB 1: USERS MANAGEMENT TABLE */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          {/* Table Search & Filter Toolbar */}
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50/50">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Pesquisar gestor por nome, e-mail ou hospital..."
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-purple-600 focus:border-purple-600 bg-white outline-none"
              />
            </div>

            <div className="text-xs text-slate-500 font-medium">
              Administrador em sessão: <strong className="text-slate-900">{currentUser.name}</strong>
            </div>
          </div>

          {/* Table Container */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-100 text-slate-600 uppercase text-[11px] font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Utilizador / Nome</th>
                  <th className="py-3 px-4">Perfil & Função</th>
                  <th className="py-3 px-4">Hospital Afeto</th>
                  <th className="py-3 px-4">Estado</th>
                  <th className="py-3 px-4 text-right">Ações de Gestão</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{user.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{user.email}</div>
                      {user.phone && <div className="text-[10px] text-slate-400">{user.phone}</div>}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          user.role === 'admin'
                            ? 'bg-purple-100 text-purple-900 border border-purple-200'
                            : 'bg-teal-100 text-teal-900 border border-teal-200'
                        }`}>
                          {user.role === 'admin' ? 'Administrador' : 'Gestor'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-700 mt-0.5">{user.title}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-medium text-slate-800">{user.assignedHospital}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => toggleManagerStatus(user.id)}
                        disabled={user.id === currentUser.id}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold transition-colors ${
                          user.isActive
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-500 border border-slate-200 hover:bg-slate-200'
                        } ${user.id === currentUser.id ? 'cursor-not-allowed opacity-80' : 'cursor-pointer'}`}
                        title={user.id === currentUser.id ? 'Não pode desativar a sua própria conta' : 'Clique para alternar estado'}
                      >
                        {user.isActive ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <XCircle className="w-3.5 h-3.5 text-slate-400" />}
                        <span>{user.isActive ? 'Ativo' : 'Inativo'}</span>
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEditModal(user)}
                          className="px-2.5 py-1 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors"
                        >
                          Editar
                        </button>
                        
                        {user.id !== currentUser.id ? (
                          <button
                            onClick={() => setDeleteTargetUser(user)}
                            className="px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 hover:text-rose-800 rounded transition-colors flex items-center gap-1"
                            title="Remover este gestor do sistema"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remover</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic px-2 py-0.5 bg-slate-50 rounded border border-slate-100">
                            Conta Ativa
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: SYSTEM CONFIGURATION & PARAMETERS */}
      {activeTab === 'settings' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900 mb-1">
              Parametrização Central dos Gabinetes de Utente
            </h2>
            <p className="text-xs text-slate-500">
              Valores institucionais e regulamentos aplicáveis ao Hospital Central de Quelimane e Hospital Geral de Quelimane.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-6 max-w-3xl text-xs">
            {/* SECTION 1: OFFICIAL OFFICE CONTACTS FOR CALLS, SMS & WHATSAPP */}
            <div className="p-4 bg-teal-50/60 border border-teal-200 rounded-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-teal-950 flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-teal-700" />
                  <span>Contactos Oficiais do Gabinete (SMS, Chamadas & WhatsApp)</span>
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-200 text-teal-900 uppercase">
                  Canal Institucional Ativo
                </span>
              </div>
              <p className="text-xs text-teal-800">
                Estes são os contactos associados ao sistema. São utilizados para o envio de mensagens e exibidos aos utentes no portal público e no comprovativo de protocolo.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Mobile / WhatsApp Contact */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-teal-600" />
                    <span>Telemóvel Oficial do Gabinete (SMS & WhatsApp)</span>
                  </label>
                  <input
                    type="text"
                    value={whatsappPhone}
                    onChange={(e) => setWhatsappPhone(e.target.value)}
                    placeholder="+258 84 123 4567"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 font-mono bg-white"
                    required
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Usado para enviar SMS reais, atender utentes no WhatsApp e realizar chamadas.
                  </span>
                </div>

                {/* Toll-Free / Landline Hotline */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                    <PhoneCall className="w-3.5 h-3.5 text-teal-600" />
                    <span>Linha Verde de Atendimento Telefónico (Chamadas)</span>
                  </label>
                  <input
                    type="text"
                    value={hotlinePhone}
                    onChange={(e) => setHotlinePhone(e.target.value)}
                    placeholder="800 123 456 ou +258 24 21 0000"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 font-mono bg-white"
                    required
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Linha telefónica institucional visível ao cidadão para acolhimento de chamadas.
                  </span>
                </div>

                {/* Official Email */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-indigo-600" />
                    <span>E-mail Institucional do Gabinete</span>
                  </label>
                  <input
                    type="email"
                    value={officialEmail}
                    onChange={(e) => setOfficialEmail(e.target.value)}
                    placeholder="gabinete.utente@hospital.gov.mz"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 font-mono bg-white"
                    required
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Remetente institucional de pareceres formais e notificações por correio.
                  </span>
                </div>

                {/* Operating Hours */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Horário de Funcionamento da Linha</span>
                  </label>
                  <input
                    type="text"
                    value={operatingHours}
                    onChange={(e) => setOperatingHours(e.target.value)}
                    placeholder="Segunda a Sexta-feira, das 07h30 às 15h30"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 bg-white"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Período em que a equipa do Gabinete está disponível para atendimento em direto.
                  </span>
                </div>

                {/* Physical Location */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-rose-600" />
                    <span>Localização Física do Gabinete de Utente</span>
                  </label>
                  <input
                    type="text"
                    value={locationOffice}
                    onChange={(e) => setLocationOffice(e.target.value)}
                    placeholder="Hospital Central de Quelimane (Piso 0, Sala 12) & Hospital Geral de Quelimane"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 bg-white"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Indicação do local presencial de atendimento ao cidadão nas unidades hospitalares.
                  </span>
                </div>
              </div>
            </div>

            {/* SECTION 2: SLA & RESOLUTION TIMELINES */}
            <div className="pt-2 border-t border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-purple-700" />
                <span>Prazos Oficiais e Padrões de Qualidade (SLA)</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    SLA de Resposta Inicial (Horas)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={slaHours}
                      onChange={(e) => setSlaHours(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600 bg-white"
                    />
                    <span className="text-slate-500 font-medium">horas</span>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Prazo regulamentar de acolhimento e confirmação ao utente.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Prazo Máximo de Conclusão / Parecer (Dias)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={slaMaxDays}
                      onChange={(e) => setSlaMaxDays(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600 bg-white"
                    />
                    <span className="text-slate-500 font-medium">dias úteis</span>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Prazo para inquérito técnico e parecer conclusivo do conselho.
                  </span>
                </div>
              </div>
            </div>

            {/* SECTION 3: SMS GATEWAY & BALANCE USAGE CONFIGURATION */}
            <div className="pt-4 border-t border-slate-200 space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-teal-700" />
                  <span>Gateway de Mensagens SMS: Como Usar o Saldo do Cartão SIM</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-100 text-teal-800 uppercase">
                    Telecomunicações Moçambique
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Defina como o sistema deve debitar o saldo de SMS para entregar mensagens físicas aos telemóveis dos utentes (Vodacom, Movitel, TMCEL).
                </p>
              </div>

              {/* Mode Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  Método de Débito de Saldo de SMS:
                </label>
                <select
                  value={smsProvider}
                  onChange={(e) => setSmsProvider(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 bg-white font-medium"
                >
                  <option value="manual_sim">
                    ✓ 1. Saldo do Cartão SIM no Telemóvel do Gabinete (Recomendado - NÃO PRECISA DE TOKEN)
                  </option>
                  <option value="android_gateway">
                    2. Android SMS Gateway (Disparo Automático com App Instalada - Requer Token da App)
                  </option>
                  <option value="bulksms_mz">
                    3. BulkSMS Moçambique (Contrato Web Corporativo - Requer Token da Plataforma)
                  </option>
                  <option value="vodacom_api">
                    4. Vodacom Moçambique API Corporativa (Requer Token Vodacom)
                  </option>
                  <option value="infobip">
                    5. Infobip Africa SMS Gateway (Requer Token Infobip)
                  </option>
                  <option value="twilio">
                    6. Twilio Global SMS Service (Requer Token Twilio)
                  </option>
                </select>
              </div>

              {/* Dynamic Settings according to chosen mode */}
              {smsProvider === 'manual_sim' && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2.5 text-xs text-emerald-950">
                  <div className="flex items-center justify-between">
                    <div className="font-bold flex items-center gap-1.5 text-emerald-900 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Sem Token! Envio Direto com o Saldo do seu Telemóvel:</span>
                    </div>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold uppercase">
                      Pronto a Usar
                    </span>
                  </div>
                  <p className="leading-relaxed">
                    <strong>Não precisa de procurar nenhum Token!</strong> Se o seu telemóvel associado (<strong>{whatsappPhone}</strong>) já tem saldo normal ou pacote de SMS da sua operadora (Vodacom, Movitel ou TMCEL), o processo é 100% automático e simples:
                  </p>
                  <ol className="list-decimal list-inside space-y-1 text-emerald-900 text-[11px] pl-1 font-medium">
                    <li>Abra a manifestação do utente no painel do Gabinete e escreva o parecer.</li>
                    <li>Clique no botão verde: <strong>"📱 Enviar SMS Real pelo Telemóvel"</strong>.</li>
                    <li>O seu telemóvel abre a app de SMS oficial com o número do utente e a mensagem prontos.</li>
                    <li>Basta tocar em <strong>Enviar</strong>! O SMS é entregue de imediato e o custo debita do saldo ou pacote de SMS do seu próprio cartão SIM.</li>
                  </ol>
                  <p className="text-[10px] text-emerald-800 italic pt-1 border-t border-emerald-200/80">
                    💡 Tokens só são necessários se for contratar serviços em nuvem pagos de terceiros. Com o seu telemóvel, não precisa de nada disso.
                  </p>
                </div>
              )}

              {smsProvider === 'android_gateway' && (
                <div className="p-4 bg-teal-50 border border-teal-200 rounded-xl space-y-3 text-xs">
                  <div className="font-bold text-teal-950 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-teal-700" />
                    <span>Transformar o seu Telemóvel com Saldo num Gateway Automático:</span>
                  </div>
                  <p className="text-teal-800 leading-relaxed">
                    Se deseja que o telemóvel do Gabinete envie os SMS <strong>100% sozinho em segundo plano</strong> gastando o saldo do cartão SIM:
                  </p>
                  <ol className="list-decimal list-inside space-y-1 text-teal-900 text-[11px] pl-1">
                    <li>Instale no smartphone do Gabinete uma aplicação de gateway SMS gratuita (ex.: <em>Traccar SMS Gateway</em> ou <em>SMS Gateway API</em>).</li>
                    <li>A app conecta o cartão SIM do telemóvel ao sistema e fornece uma URL local ou de nuvem.</li>
                    <li>Preencha a URL e a Chave de Acesso nos campos abaixo e guarde.</li>
                  </ol>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        URL / Endpoint do Gateway Android:
                      </label>
                      <input
                        type="text"
                        value={androidGatewayUrl}
                        onChange={(e) => setAndroidGatewayUrl(e.target.value)}
                        placeholder="http://192.168.1.50:8080 ou https://gateway.me/api"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 font-mono bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Token de Autenticação da App:
                      </label>
                      <input
                        type="password"
                        value={smsApiKey}
                        onChange={(e) => setSmsApiKey(e.target.value)}
                        placeholder="Token gerado pela app no telemóvel"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-teal-600 font-mono bg-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {(smsProvider === 'bulksms_mz' || smsProvider === 'vodacom_api' || smsProvider === 'infobip' || smsProvider === 'twilio') && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Remetente Institucional (Sender ID / Máscara)
                    </label>
                    <input
                      type="text"
                      value={smsSenderId}
                      onChange={(e) => setSmsSenderId(e.target.value)}
                      placeholder="ex: HCQ-SAUDE ou GAB-UTENTE"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600 font-mono uppercase bg-white"
                    />
                    <span className="text-[10px] text-slate-400 mt-0.5 block">Nome alfanumérico exibido como remetente</span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Chave de API do Provedor de Nuvem
                    </label>
                    <input
                      type="password"
                      value={smsApiKey}
                      onChange={(e) => setSmsApiKey(e.target.value)}
                      placeholder={smsApiKey ? '••••••••••••••••' : 'Insira a chave de API da conta web'}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600 font-mono bg-white"
                    />
                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      {smsApiKey ? '✓ Chave configurada' : 'Insira a chave para envio automático'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {savedSettingsNotice && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Parâmetros institucionais gravados com sucesso no sistema!</span>
              </div>
            )}

            <div className="pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
              >
                Guardar Configurações
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: AUDIT TRAIL LOGS */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Registo Cronológico de Atividades e Auditoria
              </h2>
              <p className="text-xs text-slate-500">
                Trilha imutável de eventos administrativos e operacionais no Gabinete de Utente.
              </p>
            </div>
            <span className="text-xs font-mono bg-slate-100 px-2.5 py-1 rounded text-slate-700 font-bold">
              {auditLogs.length} eventos registados
            </span>
          </div>

          <div className="space-y-2.5">
            {auditLogs.map((log) => (
              <div 
                key={log.id} 
                className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{log.action}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-purple-700 font-medium">{log.actorName}</span>
                    <span className="text-[10px] bg-slate-200 px-1.5 py-0.2 rounded text-slate-700 uppercase font-mono">
                      {log.actorRole}
                    </span>
                  </div>
                  <p className="text-slate-600">{log.details}</p>
                </div>
                <div className="text-[11px] font-mono text-slate-400 sm:text-right shrink-0">
                  {new Date(log.timestamp).toLocaleString('pt-PT')}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: REGISTER / EDIT MANAGER */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col">
            
            {/* Modal Header */}
            <div className="p-6 bg-purple-900 text-white relative">
              <button
                onClick={() => setIsModalOpen(false)}
                className="absolute top-4 right-4 text-purple-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="w-10 h-10 rounded-xl bg-purple-800 border border-purple-700 flex items-center justify-center mb-2">
                <UserPlus className="w-5 h-5 text-purple-200" />
              </div>

              <h2 className="text-lg font-bold tracking-tight">
                {editingUserId ? 'Editar Gestor' : 'Cadastrar Novo Gestor do Gabinete'}
              </h2>
              <p className="text-xs text-purple-200 mt-1">
                Atribua credenciais (e-mail pessoal ou profissional) e vincule a unidade hospitalar de serviço.
              </p>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveUser} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nome Completo <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="ex: Dr. António Macamo"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    E-mail (Pessoal ou Profissional) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="ex: pauloantonio388@gmail.com ou nome@gmail.com"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Palavra-passe de Acesso <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    placeholder="Senha temporária"
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nível de Acesso / Perfil <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600 bg-white"
                  >
                    <option value="gestor">Gestor do Gabinete (Operacional & Respostas)</option>
                    <option value="admin">Administrador do Sistema (Gestão Total)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cargo / Título Institucional <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder="ex: Ouvidor Chefe / Auditor Clínico"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Unidade Hospitalar Vinculada <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formHospital}
                    onChange={(e) => setFormHospital(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600 bg-white"
                  >
                    <option value="Hospital Central de Quelimane">Hospital Central de Quelimane</option>
                    <option value="Hospital Geral de Quelimane">Hospital Geral de Quelimane</option>
                    <option value="Hospital Central & Geral de Quelimane">Hospital Central & Geral de Quelimane (Coordenação Provincial)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Telefone Institucional (Opcional)
                  </label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="+258 84 000 0000"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-purple-600"
                  />
                </div>

              </div>

              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-purple-700 hover:bg-purple-800 rounded-lg transition-colors shadow-sm"
                >
                  {editingUserId ? 'Guardar Alterações' : 'Concluir Cadastro'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MODAL: DELETE CONFIRMATION */}
      {deleteTargetUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col">
            <div className="p-6 bg-rose-900 text-white relative">
              <button
                onClick={() => setDeleteTargetUser(null)}
                className="absolute top-4 right-4 text-rose-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-rose-800 border border-rose-700 flex items-center justify-center mb-2">
                <AlertTriangle className="w-5 h-5 text-rose-200" />
              </div>
              <h2 className="text-lg font-bold">Remover Gestor do Sistema</h2>
              <p className="text-xs text-rose-200 mt-1">
                Confirmação de eliminação de conta e revogação de acessos.
              </p>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl">
                <span className="text-[10px] font-bold text-rose-900 uppercase block mb-1">
                  Gestor a ser removido:
                </span>
                <p className="text-sm font-bold text-slate-900">{deleteTargetUser.name}</p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">{deleteTargetUser.email}</p>
                <p className="text-xs text-slate-500 mt-1">
                  {deleteTargetUser.title} · {deleteTargetUser.assignedHospital}
                </p>
              </div>

              <p className="text-slate-600 leading-relaxed">
                Tem a certeza de que pretende remover a conta deste gestor? O utilizador deixará de ter permissões de acesso ao Gabinete de Utente.
              </p>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDeleteTargetUser(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors shadow-sm flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Sim, Remover Gestor</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
