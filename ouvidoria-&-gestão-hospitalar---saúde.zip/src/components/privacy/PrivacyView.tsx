import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  EyeOff, 
  FileText, 
  CheckCircle2, 
  Scale, 
  Building,
  UserCheck
} from 'lucide-react';

export const PrivacyView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Title Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2.5 text-xs font-semibold text-teal-800 uppercase tracking-wider mb-2">
          <ShieldCheck className="w-4 h-4 text-teal-700" />
          <span>Segurança, Confidencialidade e Bioética</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 mb-2">
          Política de Privacidade e Proteção de Dados Hospitalares
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          Esta plataforma do Gabinete de Utente Hospitalar foi desenvolvida com padrões rigorosos de segurança da informação 
          e em conformidade com as legislações de proteção da privacidade dos utentes e trabalhadores de saúde.
        </p>
      </div>

      {/* Main Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
          <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
            <EyeOff className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Garantia de Anonimato Total</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Caso o utente selecione o modo anónimo, os identificadores pessoais (nome, telefone e e-mail) 
            não são associados ao relato e nunca são repassados aos profissionais ou departamentos criticados.
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
          <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
            <Lock className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Acesso Restrito & Auditoria</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Apenas membros designados do Gabinete do Utente e da Comissão de Qualidade possuem credenciais para 
            consultar os detalhes das manifestações e introduzir notas internas confidenciais.
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
          <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
            <Scale className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-bold text-slate-900">Princípio da Não Retaliação</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Nenhum paciente, familiar ou funcionário poderá sofrer prejuízo ou discriminação em razão de ter 
            exercido o direito de registar uma reclamação, sugestão ou elogio institucional.
          </p>
        </div>
      </div>

      {/* Legal Framework Details */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-6">
        <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <FileText className="w-4 h-4 text-teal-700" />
          <span>Enquadramento Jurídico e Normativo Aplicável</span>
        </h2>

        <div className="space-y-4 text-xs text-slate-700 leading-relaxed">
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
            <strong className="text-slate-900 block text-sm">
              Lei de Proteção de Dados Pessoais de Moçambique (Lei nº 3/2023)
            </strong>
            <p>
              Em conformidade com a legislação moçambicana, os dados pessoais recolhidos destinam-se exclusivamente 
              à finalidade legítima de tratamento da manifestação de saúde, com aplicação dos princípios de licitude, 
              lealdade, proporcionalidade e segurança técnica contra acessos não autorizados.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
            <strong className="text-slate-900 block text-sm">
              Sigilo Médico e Deontologia das Profissões de Saúde
            </strong>
            <p>
              Os dados clínicos porventura relatados em anexos ou descrições são tratados sob estrito dever de sigilo 
              profissional, salvaguardando a privacidade do histórico de saúde do paciente em todas as etapas da averiguação.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
            <strong className="text-slate-900 block text-sm">
              Direito de Acesso, Retificação e Cancelamento
            </strong>
            <p>
              O titular dos dados pode a qualquer momento consultar as informações fornecidas informando o número de protocolo 
              ou contactando diretamente a coordenação do Gabinete do Utente para esclarecimentos ou exclusão após o encerramento do processo.
            </p>
          </div>
        </div>

        {/* Contact Info for DPO / Ombudsman */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
          <div>
            <span className="font-semibold text-slate-900 block">
              Encarregado de Proteção de Dados (DPO) & Gabinete de Utente Hospitalar
            </span>
            <span className="text-slate-500">
              E-mail: gabinete.utente@hospital.gov.mz · Linha Verde Direta: 800 123 456 (Gratuita)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
