import React, { useState } from 'react';
import { CheckCircle2, Copy, Check, Printer, ArrowRight, ShieldCheck, X } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  protocolNumber: string;
  accessPin: string;
  onTrackNow: (protocolNumber: string, accessPin: string) => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  protocolNumber,
  accessPin,
  onTrackNow,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Protocolo: ${protocolNumber} | PIN: ${accessPin}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Bar */}
        <div className="p-6 bg-teal-800 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-teal-200 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="w-12 h-12 rounded-xl bg-teal-700/80 border border-teal-600 flex items-center justify-center mb-3">
            <CheckCircle2 className="w-7 h-7 text-teal-200" />
          </div>
          <h2 className="text-xl font-bold tracking-tight">Manifestação Registada com Sucesso!</h2>
          <p className="text-xs text-teal-100 mt-1">
            O seu feedback foi recebido pelo Gabinete de Utente Hospitalar e já se encontra em triagem.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase text-slate-500">Número do Protocolo</span>
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-xs text-teal-700 hover:text-teal-900 font-semibold"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado!' : 'Copiar'}</span>
              </button>
            </div>
            
            <div className="text-2xl font-bold text-slate-900 font-mono tracking-wider">
              {protocolNumber}
            </div>

            <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">PIN de Acesso Confidencial:</span>
              <span className="font-mono font-bold text-sm bg-slate-200 px-2.5 py-0.5 rounded text-slate-800">
                {accessPin}
              </span>
            </div>
          </div>

          <div className="text-xs text-slate-600 space-y-2 leading-relaxed">
            <div className="flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <span>
                <strong>Guarde este número e o PIN.</strong> Caso tenha optado por anonimato, estas são as únicas chaves 
                para consultar as respostas e providências tomadas pela equipa do Gabinete de Utente.
              </span>
            </div>
            <div className="text-slate-500 pl-6">
              Prazo estimado para primeira resposta do Gabinete de Utente: <strong>até 48 horas úteis</strong>.
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={handlePrint}
              type="button"
              className="w-full sm:w-auto px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <Printer className="w-4 h-4 text-slate-600" />
              <span>Imprimir Comprovativo</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onTrackNow(protocolNumber, accessPin);
              }}
              type="button"
              className="w-full sm:flex-1 px-4 py-2.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <span>Acompanhar Este Protocolo Agora</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
