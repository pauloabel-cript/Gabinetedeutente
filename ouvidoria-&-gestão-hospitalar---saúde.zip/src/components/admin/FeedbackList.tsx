import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  ChevronRight, 
  ChevronDown,
  ChevronUp,
  Shield, 
  FileText,
  Calendar,
  CalendarDays,
  Clock,
  CheckCircle2,
  RefreshCw,
  Layers,
  MessageSquareWarning,
  Lightbulb,
  MessageSquareHeart,
  BarChart3
} from 'lucide-react';
import { FeedbackItem, FeedbackPriority, FeedbackStatus, FeedbackType, HospitalSector, IntakeChannel } from '../../types/feedback';
import { HOSPITAL_SECTORS, HOSPITAL_UNITS } from '../../data/mockData';

interface FeedbackListProps {
  feedbacks: FeedbackItem[];
  onSelectFeedback: (id: string) => void;
  onOpenManualEntry: () => void;
  initialTypeFilter?: FeedbackType;
  initialStatusFilter?: FeedbackStatus;
}

export const FeedbackList: React.FC<FeedbackListProps> = ({
  feedbacks,
  onSelectFeedback,
  onOpenManualEntry,
  initialTypeFilter,
  initialStatusFilter,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<FeedbackType | 'all'>(initialTypeFilter || 'all');
  const [statusFilter, setStatusFilter] = useState<FeedbackStatus | 'all'>(initialStatusFilter || 'all');
  const [sectorFilter, setSectorFilter] = useState<HospitalSector | 'all'>('all');
  const [unitFilter, setUnitFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<FeedbackPriority | 'all'>('all');
  const [channelFilter, setChannelFilter] = useState<IntakeChannel | 'all'>('all');
  
  // Separation by days controls
  const [groupByDate, setGroupByDate] = useState<boolean>(true);
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'custom'>('all');
  const [customDate, setCustomDate] = useState<string>('');
  const [collapsedDays, setCollapsedDays] = useState<Record<string, boolean>>({});

  const toggleDayCollapse = (dateKey: string) => {
    setCollapsedDays(prev => ({
      ...prev,
      [dateKey]: !prev[dateKey]
    }));
  };

  // Filtered items
  const filteredFeedbacks = useMemo(() => {
    return feedbacks.filter((item) => {
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchProto = item.protocolNumber.toLowerCase().includes(q);
        const matchSubj = item.subject.toLowerCase().includes(q);
        const matchDesc = item.description.toLowerCase().includes(q);
        const matchName = item.reporterName?.toLowerCase().includes(q);
        const matchUnit = item.facilityUnit.toLowerCase().includes(q);
        if (!matchProto && !matchSubj && !matchDesc && !matchName && !matchUnit) {
          return false;
        }
      }

      // Hospital Unit
      if (unitFilter !== 'all' && item.facilityUnit !== unitFilter) return false;

      // Type
      if (typeFilter !== 'all' && item.type !== typeFilter) return false;

      // Status
      if (statusFilter !== 'all' && item.status !== statusFilter) return false;

      // Sector
      if (sectorFilter !== 'all' && item.sector !== sectorFilter) return false;

      // Priority
      if (priorityFilter !== 'all' && item.priority !== priorityFilter) return false;

      // Channel
      if (channelFilter !== 'all' && item.channel !== channelFilter) return false;

      // Date filtering
      if (dateFilter !== 'all') {
        const itemDate = new Date(item.createdAt);
        const now = new Date();
        const todayStr = now.toISOString().slice(0, 10);
        
        const yesterday = new Date(now);
        yesterday.setDate(now.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().slice(0, 10);
        
        const itemDateStr = item.createdAt.slice(0, 10);

        if (dateFilter === 'today' && itemDateStr !== todayStr) return false;
        if (dateFilter === 'yesterday' && itemDateStr !== yesterdayStr) return false;
        if (dateFilter === 'last7') {
          const diffTime = Math.abs(now.getTime() - itemDate.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          if (diffDays > 7) return false;
        }
        if (dateFilter === 'thisMonth') {
          if (itemDate.getMonth() !== now.getMonth() || itemDate.getFullYear() !== now.getFullYear()) return false;
        }
        if (dateFilter === 'custom' && customDate && itemDateStr !== customDate) return false;
      }

      return true;
    });
  }, [
    feedbacks, 
    searchQuery, 
    unitFilter, 
    typeFilter, 
    statusFilter, 
    sectorFilter, 
    priorityFilter, 
    channelFilter,
    dateFilter,
    customDate
  ]);

  // Group items by Day
  const groupedByDay = useMemo(() => {
    // Sort by createdAt descending
    const sorted = [...filteredFeedbacks].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    const map = new Map<string, FeedbackItem[]>();
    sorted.forEach(item => {
      const key = item.createdAt.slice(0, 10);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(item);
    });

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().slice(0, 10);

    const groups: {
      dateKey: string;
      formattedDate: string;
      isToday: boolean;
      isYesterday: boolean;
      items: FeedbackItem[];
      recsCount: number;
      sugsCount: number;
      elosCount: number;
    }[] = [];

    map.forEach((items, key) => {
      const parts = key.split('-');
      const d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
      
      const formatted = d.toLocaleDateString('pt-PT', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });
      const formattedDate = formatted.charAt(0).toUpperCase() + formatted.slice(1);
      
      groups.push({
        dateKey: key,
        formattedDate,
        isToday: key === todayStr,
        isYesterday: key === yesterdayStr,
        items,
        recsCount: items.filter(i => i.type === 'reclamacao').length,
        sugsCount: items.filter(i => i.type === 'sugestao').length,
        elosCount: items.filter(i => i.type === 'elogio').length,
      });
    });

    return groups;
  }, [filteredFeedbacks]);

  const getSectorLabel = (sectorId: string) => {
    const s = HOSPITAL_SECTORS.find(sec => sec.id === sectorId);
    return s ? s.label : sectorId;
  };

  const getStatusText = (status: FeedbackStatus) => {
    switch (status) {
      case 'recebido': return 'Recebido';
      case 'em_analise': return 'Em Análise';
      case 'em_atendimento': return 'Em Atendimento';
      case 'resolvido': return 'Resolvido';
      case 'arquivado': return 'Arquivado';
    }
  };

  const getStatusBadgeClass = (status: FeedbackStatus) => {
    switch (status) {
      case 'resolvido': return 'text-emerald-800 bg-emerald-50 border border-emerald-200';
      case 'em_atendimento': return 'text-amber-800 bg-amber-50 border border-amber-200';
      case 'em_analise': return 'text-blue-800 bg-blue-50 border border-blue-200';
      case 'recebido': return 'text-slate-800 bg-slate-100 border border-slate-200';
      case 'arquivado': return 'text-slate-500 bg-slate-50 border border-slate-200';
    }
  };

  const getTypeColor = (type: FeedbackType) => {
    switch (type) {
      case 'reclamacao': return 'text-rose-700';
      case 'elogio': return 'text-emerald-700';
      case 'sugestao': return 'text-indigo-700';
    }
  };

  const resetFilters = () => {
    setSearchQuery('');
    setTypeFilter('all');
    setStatusFilter('all');
    setSectorFilter('all');
    setUnitFilter('all');
    setPriorityFilter('all');
    setChannelFilter('all');
    setDateFilter('all');
    setCustomDate('');
  };

  // Helper renderer for table row
  const renderItemRow = (item: FeedbackItem) => (
    <tr
      key={item.id}
      onClick={() => onSelectFeedback(item.id)}
      className="hover:bg-teal-50/40 transition-colors cursor-pointer group"
    >
      {/* Protocol & Hour */}
      <td className="py-3 px-4 whitespace-nowrap">
        <div className="font-mono font-bold text-slate-900 tabular-nums">
          {item.protocolNumber}
        </div>
        <div className="text-[11px] text-slate-500 tabular-nums flex items-center gap-1 mt-0.5">
          <Clock className="w-3 h-3 text-slate-400" />
          <span>{new Date(item.createdAt).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}</span>
          <span className="text-slate-300">·</span>
          <span>{new Date(item.createdAt).toLocaleDateString('pt-PT')}</span>
        </div>
      </td>

      {/* Type badge */}
      <td className="py-3 px-4 whitespace-nowrap">
        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold capitalize ${
          item.type === 'reclamacao' 
            ? 'bg-rose-50 text-rose-800 border border-rose-200' 
            : item.type === 'elogio'
            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
        }`}>
          {item.type === 'reclamacao' && <MessageSquareWarning className="w-3 h-3 text-rose-600" />}
          {item.type === 'elogio' && <MessageSquareHeart className="w-3 h-3 text-emerald-600" />}
          {item.type === 'sugestao' && <Lightbulb className="w-3 h-3 text-indigo-600" />}
          <span>{item.type}</span>
        </span>
        <div className="text-[10px] text-slate-400 capitalize mt-0.5">
          via {item.channel}
        </div>
      </td>

      {/* Subject & Description */}
      <td className="py-3 px-4 max-w-[280px]">
        <div className="font-semibold text-slate-900 truncate">
          {item.subject}
        </div>
        <div className="text-[11px] text-slate-500 truncate">
          {item.description}
        </div>
      </td>

      {/* Sector */}
      <td className="py-3 px-4 max-w-[210px]">
        <div className="font-medium text-slate-800 truncate">
          {getSectorLabel(item.sector)}
        </div>
        <div className="text-[10px] text-teal-800 font-medium truncate">
          {item.facilityUnit}
        </div>
      </td>

      {/* Reporter */}
      <td className="py-3 px-4 whitespace-nowrap">
        {item.isAnonymous ? (
          <div className="flex items-center gap-1 text-slate-500 italic">
            <Shield className="w-3 h-3 text-amber-600" />
            <span>Anónimo</span>
          </div>
        ) : (
          <div className="text-slate-800 font-medium">
            {item.reporterName || 'Utente'}
          </div>
        )}
        <div className="text-[10px] text-slate-400 capitalize">
          {item.reporterRole}
        </div>
      </td>

      {/* Priority */}
      <td className="py-3 px-4 whitespace-nowrap">
        <span className={`font-mono text-[11px] font-semibold uppercase ${
          item.priority === 'critica'
            ? 'text-rose-700'
            : item.priority === 'alta'
            ? 'text-amber-700'
            : item.priority === 'media'
            ? 'text-slate-700'
            : 'text-slate-400'
        }`}>
          {item.priority}
        </span>
      </td>

      {/* Status */}
      <td className="py-3 px-4 whitespace-nowrap">
        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${getStatusBadgeClass(item.status)}`}>
          {getStatusText(item.status)}
        </span>
      </td>

      {/* Action Arrow */}
      <td className="py-3 px-4 text-right whitespace-nowrap">
        <span className="text-xs font-semibold text-teal-700 group-hover:translate-x-1 inline-flex items-center gap-0.5 transition-transform">
          <span>Ver</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </span>
      </td>
    </tr>
  );

  return (
    <div className="space-y-4">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        {/* Search input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Pesquisar por protocolo, utente, assunto ou palavras-chave..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-teal-600 focus:border-teal-600 outline-none"
          />
        </div>

        {/* View Mode Toggle & Register Action */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Day Separation Switch */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setGroupByDate(true)}
              className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${
                groupByDate
                  ? 'bg-teal-700 text-white shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Separar as manifestações por dia de registo"
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Separar por Dias</span>
            </button>
            <button
              onClick={() => setGroupByDate(false)}
              className={`px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 ${
                !groupByDate
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Ver todas as manifestações em tabela contínua"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Lista Corrida</span>
            </button>
          </div>

          <button
            onClick={onOpenManualEntry}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Registar Atendimento</span>
          </button>
        </div>
      </div>

      {/* Filter Controls Row */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-xs">
        {/* Type Segmented Controls */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-medium">
            {[
              { id: 'all', label: `Todos (${feedbacks.length})` },
              { id: 'reclamacao', label: `Reclamações (${feedbacks.filter(f => f.type === 'reclamacao').length})` },
              { id: 'elogio', label: `Elogios (${feedbacks.filter(f => f.type === 'elogio').length})` },
              { id: 'sugestao', label: `Sugestões (${feedbacks.filter(f => f.type === 'sugestao').length})` },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setTypeFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                  typeFilter === tab.id
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {(typeFilter !== 'all' || statusFilter !== 'all' || sectorFilter !== 'all' || priorityFilter !== 'all' || channelFilter !== 'all' || dateFilter !== 'all' || searchQuery) && (
            <button
              onClick={resetFilters}
              className="text-xs text-slate-500 hover:text-rose-700 flex items-center gap-1 font-semibold"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Limpar Filtros</span>
            </button>
          )}
        </div>

        {/* Secondary Filter Dropdowns */}
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 pt-2 border-t border-slate-100 text-xs">
          {/* Day / Period Filter */}
          <div>
            <label className="block text-[11px] font-bold text-teal-900 mb-1 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-teal-600" />
              <span>Filtrar por Dia</span>
            </label>
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-teal-300 rounded-md bg-teal-50/40 text-teal-950 font-medium focus:outline-none focus:ring-1 focus:ring-teal-600"
            >
              <option value="all">Todos os Dias</option>
              <option value="today">Hoje</option>
              <option value="yesterday">Ontem</option>
              <option value="last7">Últimos 7 dias</option>
              <option value="thisMonth">Este Mês</option>
              <option value="custom">Data Específica...</option>
            </select>
          </div>

          {/* Hospital Unit */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Unidade Hospitalar</label>
            <select
              value={unitFilter}
              onChange={(e) => setUnitFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-600 truncate"
            >
              <option value="all">Todas as Unidades</option>
              {HOSPITAL_UNITS.map(u => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
          </div>

          {/* Status */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-600"
            >
              <option value="all">Todos os Status</option>
              <option value="recebido">Recebido</option>
              <option value="em_analise">Em Análise</option>
              <option value="em_atendimento">Em Atendimento</option>
              <option value="resolvido">Resolvido</option>
              <option value="arquivado">Arquivado</option>
            </select>
          </div>

          {/* Sector */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Setor Hospitalar</label>
            <select
              value={sectorFilter}
              onChange={(e) => setSectorFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-600 truncate"
            >
              <option value="all">Todos os Setores</option>
              {HOSPITAL_SECTORS.map(s => (
                <option key={s.id} value={s.id}>{s.label}</option>
              ))}
            </select>
          </div>

          {/* Priority */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Prioridade</label>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-600"
            >
              <option value="all">Todas as Prioridades</option>
              <option value="critica">Crítica (Urgência)</option>
              <option value="alta">Alta</option>
              <option value="media">Média</option>
              <option value="baixa">Baixa</option>
            </select>
          </div>

          {/* Canal */}
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">Canal de Entrada</label>
            <select
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-600"
            >
              <option value="all">Todos os Canais</option>
              <option value="web">Portal Web do Utente</option>
              <option value="telefone">Linha Verde Telefónica</option>
              <option value="presencial">Balcão Presencial</option>
            </select>
          </div>
        </div>

        {/* Custom date picker row if 'custom' is selected */}
        {dateFilter === 'custom' && (
          <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-xs">
            <span className="text-slate-600 font-medium">Selecione o dia específico:</span>
            <input
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="px-3 py-1.5 border border-teal-300 rounded-md bg-white text-slate-900 font-mono text-xs outline-none focus:ring-1 focus:ring-teal-600"
            />
            {customDate && (
              <button
                onClick={() => setCustomDate('')}
                className="text-[11px] text-rose-600 hover:underline"
              >
                Limpar data
              </button>
            )}
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {filteredFeedbacks.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-xs">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-700 mb-1">
            Nenhuma manifestação encontrada com os filtros selecionados
          </p>
          <button
            onClick={resetFilters}
            className="text-xs font-semibold text-teal-700 hover:text-teal-900 mt-2"
          >
            Redefinir filtros
          </button>
        </div>
      ) : groupByDate ? (
        /* ================= GROUPED BY DAY VIEW ================= */
        <div className="space-y-4">
          {groupedByDay.map((group) => {
            const isCollapsed = collapsedDays[group.dateKey] || false;

            return (
              <div 
                key={group.dateKey} 
                className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all"
              >
                {/* DAY HEADER BAR */}
                <div 
                  onClick={() => toggleDayCollapse(group.dateKey)}
                  className="px-4 py-3 bg-slate-50/90 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 cursor-pointer hover:bg-slate-100/80 transition-colors"
                >
                  {/* Left: Day Title and Badges */}
                  <div className="flex items-center gap-3">
                    <button 
                      type="button"
                      className="w-7 h-7 rounded-lg bg-white border border-slate-300 text-slate-600 flex items-center justify-center hover:bg-teal-50 hover:text-teal-700 transition-colors shrink-0 shadow-2xs"
                    >
                      {isCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                    </button>

                    <div className="flex items-center gap-2 flex-wrap">
                      <CalendarDays className="w-4 h-4 text-teal-700 shrink-0" />
                      <span className="text-sm font-bold text-slate-900">
                        {group.formattedDate}
                      </span>

                      {group.isToday && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-100 text-emerald-800 border border-emerald-300">
                          Hoje
                        </span>
                      )}
                      {group.isYesterday && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-blue-100 text-blue-800 border border-blue-300">
                          Ontem
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right: Daily Breakdown Pills (Reclamações / Sugestões / Elogios) */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Reclamações Pill */}
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 ${
                      group.recsCount > 0 
                        ? 'bg-rose-50 text-rose-800 border border-rose-200' 
                        : 'bg-slate-100 text-slate-400'
                    }`}>
                      <MessageSquareWarning className={`w-3.5 h-3.5 ${group.recsCount > 0 ? 'text-rose-600' : 'text-slate-400'}`} />
                      <span>{group.recsCount} {group.recsCount === 1 ? 'Reclamação' : 'Reclamações'}</span>
                    </span>

                    {/* Sugestões Pill */}
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 ${
                      group.sugsCount > 0 
                        ? 'bg-indigo-50 text-indigo-800 border border-indigo-200' 
                        : 'bg-slate-100 text-slate-400'
                    }`}>
                      <Lightbulb className={`w-3.5 h-3.5 ${group.sugsCount > 0 ? 'text-indigo-600' : 'text-slate-400'}`} />
                      <span>{group.sugsCount} {group.sugsCount === 1 ? 'Sugestão' : 'Sugestões'}</span>
                    </span>

                    {/* Elogios Pill */}
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 ${
                      group.elosCount > 0 
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                        : 'bg-slate-100 text-slate-400'
                    }`}>
                      <MessageSquareHeart className={`w-3.5 h-3.5 ${group.elosCount > 0 ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{group.elosCount} {group.elosCount === 1 ? 'Elogio' : 'Elogios'}</span>
                    </span>

                    {/* Total */}
                    <span className="px-2.5 py-1 rounded-lg text-xs font-extrabold bg-slate-800 text-white shadow-2xs">
                      Total: {group.items.length}
                    </span>
                  </div>
                </div>

                {/* DAY TABLE (Collapsible) */}
                {!isCollapsed && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50/40 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                          <th className="py-2.5 px-4">Protocolo & Hora</th>
                          <th className="py-2.5 px-4">Tipo</th>
                          <th className="py-2.5 px-4">Assunto & Resumo</th>
                          <th className="py-2.5 px-4">Setor & Unidade</th>
                          <th className="py-2.5 px-4">Manifestante</th>
                          <th className="py-2.5 px-4">Prioridade</th>
                          <th className="py-2.5 px-4">Status</th>
                          <th className="py-2.5 px-4 text-right">Ação</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {group.items.map(renderItemRow)}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* ================= CONTINUOUS FLAT TABLE VIEW ================= */
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-4 py-2.5 bg-slate-50/70 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
            <span className="font-semibold">
              {filteredFeedbacks.length} {filteredFeedbacks.length === 1 ? 'manifestação encontrada' : 'manifestações encontradas'}
            </span>
            <span className="text-[11px] text-slate-400">
              Clique na linha para ver os detalhes, registar notas internas ou responder
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Protocolo & Data</th>
                  <th className="py-3 px-4">Tipo</th>
                  <th className="py-3 px-4">Assunto & Resumo</th>
                  <th className="py-3 px-4">Setor & Unidade</th>
                  <th className="py-3 px-4">Manifestante</th>
                  <th className="py-3 px-4">Prioridade</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFeedbacks.map(renderItemRow)}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
